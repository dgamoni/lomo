// =============================================================================
// JS/ADMIN/TINYMCE.JS
// -----------------------------------------------------------------------------
// TinyMCE specific functions.
// =============================================================================

(function() {

tinymce.PluginManager.add('DahzThemeShortcodes', function( editor, url ) {
    editor.addButton( 'DahzThemeShortcodes', {
      title: 'Insert Shortcode',
      icon: false,
      type: 'menubutton',
      menu: [ { // begin content
      			text: 'Content',
      			menu: [
      					{ // begin button
      						text: 'Button',
      						onclick: function() {
      							editor.windowManager.open({
      								title: 'Button Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
			                      	body: [
			                      			{
			                      			  type: 'listbox',
			                      			  name: 'button_style',
			                      			  label: 'Button Style',
			                      			  'values': [
			                      			  			  {text: 'Flat', value: 'flat'},
			                      			  			  {text: '3D', value: '3d'},
			                      			  			  {text: 'Outline', value: 'outline'}
			                      			  			]
			                      			},
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Choose your button style.";}
					                        },
					                        {
			                      			  type: 'listbox',
			                      			  name: 'button_shape',
			                      			  label: 'Button Shape',
			                      			  'values': [
			                      			  			  {text: 'Square', value: 'square'},
			                      			  			  {text: 'Rounded Rectangled', value: 'rounded'},
			                      			  			  {text: 'Round', value: 'round'}
			                      			  			]
			                      			},
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Choose your button shape.";}
					                        },
			                      			{
						                      type: 'textbox',
											  name: 'font_color',
											  label: 'Font Color',
											  value: '#FFFFFF'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
					                        },
						                    {
						                      type: 'textbox',
											  name: 'button_color',
											  label: 'Button Color',
											  value: '#343435'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Active when you choose 'Flat' or '3D'.";}
					                        },
					                        {
						                      type: 'textbox',
											  name: 'border_color',
											  label: 'Border Color',
											  value: '#343435'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
					                        },
					                        {
						                      type: 'textbox',
											  name: 'shadow_color',
											  label: 'Shadow Color',
											  value: '#030303'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Active when you choose '3D'.";}
					                        },
			                      			{
						                      type: 'textbox',
											  name: 'font_color_hover',
											  label: 'Font Color Hover',
											  value: '#FFFFFF'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                       
					                        },
						                    {
						                      type: 'textbox',
											  name: 'button_color_hover',
											  label: 'Button Color Hover',
											  value: '#030303'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Active when you choose 'Flat' or '3D'.";}
					                        },
						                    {
						                      type: 'textbox',
											  name: 'border_color_hover',
											  label: 'Border Color Hover',
											  value: '#030303'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
					                        },
						                    {
						                      type: 'textbox',
											  name: 'shadow_color_hover',
											  label: 'Shadow Color Hover',
											  value: '#343435'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Active when you choose '3D'.";}
					                        },
					                        {
						                      type: 'listbox',
											  name: 'button_size',
											  label: 'Button Size',
											  'values': [
											  			  {text:'Medium', value:'md'},
											  			  {text:'Extra Small', value:'xs'},
											  			  {text:'Small', value:'sm'},
											  			  {text:'Large', value:'lg'}
											  			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        },
					                        {
						                      type: 'listbox',
											  name: 'button_position',
											  label: 'Button Position',
											  'values': [
											  			  {text:'Left', value:'position_left'},
											  			  {text:'Center', value:'position_center'},
											  			  {text:'Right', value:'position_right'}
											  			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                     
					                        },
					                        {
						                      type: 'textbox',
											  name: 'url_link',
											  label: 'Url Link',
											  value: 'http://'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Write your Url button. e.g http://google.com.";}
					                        },
					                        {
						                      type: 'listbox',
											  name: 'target_link',
											  label: 'Target Link',
											  'values': [
											  			  {text:'New Tab', value:'_blank'},
											  			  {text:'Current Tab', value:'_self'}
											  			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Specify where to open the link.";}
					                        },
					                        {
						                      type: 'textbox',
											  name: 'title_link',
											  label: 'Link\'s tooltip Text',
											  value: ''
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Write the tooltip text on hover.";}
					                        },
					                        {
						                      type: 'textbox',
											  name: 'button_text',
											  label: 'Button Text',
											  value: 'BUTTON'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
					                        },
					                        {
						                      type: 'textbox',
											  name: 'fa_icon',
											  label: 'Font Awesome Icon',
											  value: ''
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Check the icon list here <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank' style='font-size:11px;'>Font Awesome</a>, use icon id only. e.g. 'adjust'";}
					                        },
					                        {
						                      type: 'listbox',
											  name: 'icon_size',
											  label: 'Font Awesome Size',
											  'values': [
											  			  {text: '1x', value: '1x'},
											  			  {text: '2x', value: '2x'},
											  			  {text: '3x', value: '3x'},
											  			  {text: '4x', value: '4x'},
											  			  {text: '5x', value: '5x'},
											  			  {text: 'lg', value: 'lg'}
											  			]
						                    },
						                    {
						                      type: 'listbox',
											  name: 'icon_rotate',
											  label: 'Font Awesome Rotate',
											  'values': [
											  			  {text: 'Normal', value: 'normal'},
											  			  {text: 'Rotate 90 Degrees', value: '90'},
											  			  {text: 'Rotate 180 Degrees', value: '180'},
											  			  {text: 'Rotate 270 Degrees', value: '270'}
											  			]
						                    },
						                    {
						                      type: 'listbox',
											  name: 'icon_flip',
											  label: 'Font Awesome Flip',
											  'values': [
											  			  {text: 'None', value: ''},
											  			  {text: 'Horizontal', value: 'horizontal'},
											  			  {text: 'Vertical', value: 'vertical'}
											  			]
						                    },
						                    {
						                      type: 'textbox',
											  name: 'btn_extra_class',
											  label: 'Button Extra Class',
											  value: ''
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
					                        }
			                      		  ],
			                      	onsubmit: function( e ) {
					                    editor.insertContent( '[df_button btn_style="'+e.data.button_style+'" btn_shape="'+e.data.button_shape+'" btn_position="'+e.data.button_position+'" btn_text="'+e.data.button_text+'" btn_size="'+e.data.button_size+'" font_color="'+e.data.font_color+'" font_color_hover="'+e.data.font_color_hover+'" btn_color="'+e.data.button_color+'" btn_color_hover="'+e.data.button_color_hover+'" btn_border_color="'+e.data.border_color+'" btn_border_color_hover="'+e.data.border_color_hover+'" btn_bottom_color="'+e.data.shadow_color+'" btn_bottom_color_hover="'+e.data.shadow_color_hover+'" url_link="'+e.data.url_link+'" target_link="'+e.data.target_link+'" title_link="'+e.data.title_link+'" type="'+e.data.fa_icon+'" rotate="'+e.data.icon_rotate+'" size="'+e.data.icon_size+'" flip="'+e.data.icon_flip+'" btn_el_class="'+e.data.btn_extra_class+'"]' );
					                }
			                    });
      						}
      					}, // end button
      					{ // begin divider
      						text: 'Divider',
      						onclick: function() {
      							editor.windowManager.open({
      								title: 'Divider Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
      								body: [ 
						                    {
						                      type: 'listbox',
						                      name: 'border_style',
						                      label: 'Divider Style',
						                      'values': [
						                      			  { text: 'Solid', value: 'solid'},
						                      			  { text: 'Dotted', value: 'dotted'},
						                      			  { text: 'Dashed', value: 'dashed'},
						                      			  { text: 'Double', value: 'double'},
						                      			]
						                    },
      										{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
					                        },
						                    {
						                      type: 'textbox',
											  name: 'border_color',
											  label: 'Divider Color',
											  value: '#EEEEEE'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
					                        },
						                    {
						                      type: 'listbox',
						                      name: 'border_width',
						                      label: 'Divider Width',
						                      'values': [
						                      			  { text: '100%', value: '100'},
						                      			  { text: '90%', value: '90'},
						                      			  { text: '80%', value: '80'},
						                      			  { text: '70%', value: '70'},
						                      			  { text: '60%', value: '60'},
						                      			  { text: '50%', value: '50'},
						                      			  { text: '40%', value: '40'},
						                      			  { text: '30%', value: '30'},
						                      			  { text: '20%', value: '20'},
						                      			  { text: '10%', value: '10'}
						                      			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                  	},
						                    {
						                      type: 'textbox',
											  name: 'border_size',
											  label: 'Divider Size',
											  value: '1px'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Set the border size in px. e.g: 1px.";}
					                        },
						                    {
						                      type: 'listbox',
						                      name: 'border_position',
						                      label: 'Border Alignment',
						                      'values': [
						                      			  { text: 'Center', value: 'align_center'},
						                      			  { text: 'Left', value: 'align_left'},
						                      			  { text: 'Right', value: 'align_right'},
						                      			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						             
					                        },
						                    {
						                      type: 'textbox',
											  name: 'height',
											  label: 'Height',
											  value: '1px'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Set the divider line height. active when you choose 'double'";}
					                        },
						                    {
						                      type: 'textbox',
											  name: 'padding',
											  label: 'Padding',
											  value: '22px 0'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "add padding. learn about padding properties <a target='_blank' href='http://www.w3schools.com/cssref/pr_padding.asp'>here</a> ";}
					                        },
					                        {
						                      type: 'textbox',
						                      name: 'extra_class',
						                      label: 'Extra Class'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
					                        }
						                  ],
						            onsubmit: function( e ) {
					                    editor.insertContent( '[df_divider el_width="'+ e.data.border_width +'" style="'+ e.data.border_style +'" height="'+ e.data.height +'" accent_color="'+ e.data.border_color +'" border_size="'+ e.data.border_size +'" padding="'+ e.data.padding +'" position="'+ e.data.border_position +'" el_class="'+ e.data.extra_class +'"]' );
					                }
								});
							}
      					}, // end divider
      					{ // begin divider with text
      						text: 'Divider With Text',
      						onclick: function() {
      							editor.windowManager.open({
      								title: 'Divider With Text Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
      								body: [ 
						                    {
						                      type: 'listbox',
						                      name: 'border_style',
						                      label: 'Divider Style',
						                      'values': [
						                      			  { text: 'Solid', value: 'solid'},
						                      			  { text: 'Dotted', value: 'dotted'},
						                      			  { text: 'Dashed', value: 'dashed'},
						                      			  { text: 'Double', value: 'double'},
						                      			]
						                    },
      										{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Choose divider style.";}
					                        },
						                    {
						                      type: 'textbox',
											  name: 'border_color',
											  label: 'Divider Color',
											  value: '#EEEEEE'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Set divider color.";}
					                        },
						                    {
						                      type: 'listbox',
						                      name: 'border_width',
						                      label: 'Divider Width',
						                      'values': [
						                      			  { text: '100%', value: '100'},
						                      			  { text: '90%', value: '90'},
						                      			  { text: '80%', value: '80'},
						                      			  { text: '70%', value: '70'},
						                      			  { text: '60%', value: '60'},
						                      			  { text: '50%', value: '50'},
						                      			  { text: '40%', value: '40'},
						                      			  { text: '30%', value: '30'},
						                      			  { text: '20%', value: '20'},
						                      			  { text: '10%', value: '10'}
						                      			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Choose divider width.";}
					                        },
						                    {
						                      type: 'textbox',
											  name: 'border_size',
											  label: 'Divider Size',
											  value: '1px'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Set the border size in px. e.g: 1px.";}
					                        },
						                    {
						                      type: 'listbox',
						                      name: 'border_position',
						                      label: 'Border Alignment',
						                      'values': [
						                      			  { text: 'Center', value: 'align_center'},
						                      			  { text: 'Left', value: 'align_left'},
						                      			  { text: 'Right', value: 'align_right'},
						                      			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Choose divider position.";}
					                        },
						                    {
						                      type: 'textbox',
											  name: 'height',
											  label: 'Height',
											  value: '1px'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Set the divider line height. active when you choose 'double'";}
					                        },
						                    {
						                      type: 'textbox',
											  name: 'padding',
											  label: 'Padding',
											  value: '22px 0'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "add padding. learn about padding properties <a href='http://www.w3schools.com/cssref/pr_padding.asp' target='_blank'>here</a>  ";}
					                        },
						                    {
						                      type: 'textbox',
						                      name: 'title',
						                      label: 'Divider Text',
						                      value: 'DIVIDER'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        },
						                    {
						                      type: 'listbox',
						                      name: 'title_align',
						                      label: 'Text Alignment',
						                      'values': [
						                      			  { text: 'Center', value: 'separator_align_center'},
						                      			  { text: 'Left', value: 'separator_align_left'},
						                      			  { text: 'Right', value: 'separator_align_right'}
						                      			]
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        },
					                        {
						                      type: 'textbox',
						                      name: 'extra_class',
						                      label: 'Extra Class'
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
					                        },
						                  ],
						            onsubmit: function( e ) {
					                    editor.insertContent( '[df_divider_text title="'+ e.data.title +'" title_align="'+ e.data.title_align +'" el_width="'+ e.data.border_width +'" style="'+ e.data.border_style +'" height="'+ e.data.height +'" accent_color="'+ e.data.border_color +'" border_size="'+ e.data.border_size +'" padding="'+ e.data.padding +'" position="'+ e.data.border_position +'" el_class="'+ e.data.extra_class +'"]' );
					                }
								});
							}
      					}, // end divider with text
      					{ // begin dropcap
      						text: 'Dropcap',
      						onclick: function() {
      							editor.windowManager.open({
      								title: 'Dropcap Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
			                      	body: [
			                      			{
			                      			  type: 'textbox',
			                      			  name: 'font_color',
			                      			  label: 'Font Color',
			                      			  value: '#FFFFFF'
			                      			},
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        },
					                        {
			                      			  type: 'textbox',
			                      			  name: 'bg_color',
			                      			  label: 'Background Color',
			                      			  value: '#0F0F0F'
			                      			},
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        },
					                        {
			                      			  type: 'textbox',
			                      			  name: 'font_weight',
			                      			  label: 'Font Weight',
			                      			  value: '400'
			                      			},
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        },
					                        {
						                      type: 'textbox',
						                      name: 'content',
						                      label: 'Content',
						                      value: 'A',
						                      multiline: true,
						                      minWidth: 300,
						                      minHeight: 100
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "You can use more than one word here.";}
					                        }
			                      		  ],
	                      			onsubmit: function( e ) {
					                    editor.insertContent( '[dropcap background_color="'+e.data.bg_color+'" color="'+e.data.font_color+'" size="'+e.data.font_weight+'"]'+e.data.content+'[/dropcap]' );
					                }
      							});
      						}
      					}, // end dropcap
      					{ // begin Highlight
      						text: 'Highlight',
      						onclick: function() {
      							editor.windowManager.open({
      								title: 'Highlight Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
			                      	body: [
			                      			{
			                      			  type: 'textbox',
			                      			  name: 'font_color',
			                      			  label: 'Font Color',
			                      			  value: '#FFFFFF'
			                      			},
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        },
					                        {
			                      			  type: 'textbox',
			                      			  name: 'bg_color',
			                      			  label: 'Background Color',
			                      			  value: '#0F0F0F'
			                      			},
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                     
					                        },
					                        {
						                      type: 'textbox',
						                      name: 'content',
						                      label: 'Text',
						                      value: 'CONTENT',
						                      multiline: true,
						                      minWidth: 300,
						                      minHeight: 100
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      
					                        }
			                      		  ],
	                      			onsubmit: function( e ) {
					                    editor.insertContent( '[highlight_sty background="'+e.data.bg_color+'" color="'+e.data.font_color+'"]'+e.data.content+'[/highlight_sty]' );
					                }
      							});
      						}
      					}, // end highlight
      					{ // begin List
      						text: 'List Item',
      						onclick: function() {
      							editor.windowManager.open({
      								title: 'List Item Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
			                      	body: [
			                      			{
			                      			  type: 'textbox',
					                          name: 'listcount',
					                          label: 'How many items ?',
					                          value: '1'
			                      			},			                      			
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Set the items.";}
					                        },
					                        {
					                          type: 'textbox',
					                          name: 'icon',
					                          label: 'What icon you want use ?',
					                          value: 'fa-'
					                        },
			                      			{ 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "Check the icon list here <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank' style='font-size:11px;'>Font Awesome</a>, use icon id only. e.g. 'adjust'.";}
					                        }
			                      		  ],
	                      			onsubmit: function( e ) {
					                    editor.insertContent('[list]');
					                    for (i = 0; i < e.data.listcount; i++) {
					                        editor.insertContent('[list_item icon="'+ e.data.icon +'"]content[/list_item]');
					                    }
					                    editor.insertContent('[/list]');
					                }
      							});
      						}
      					}, // end list
      					{/*start table*/
				            text: 'Table',
				            onclick: function() {
				                editor.windowManager.open( {
					                title: 'Insert Table Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
					                body: [
						                    {
						                      type: 'textbox',
						                      name: 'table_row',
						                      label: 'Number of row',
						                      value: '4'
						                    },
						                    {
						                      type: 'textbox',
						                      name: 'table_coloumn',
						                      label: 'Number of column',
						                      value: '4'
						                    },
						                    {
						                      type: 'textbox',
											  name: 'extra_class',
											  label: 'Extra Class',
											  value: ''
						                    },
						                    { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
					                        } 
						                  ],
					                onsubmit: function( e ) {
					                    editor.insertContent('[table el_class="'+ e.data.extra_class +'"]');
						                    for (i = 0; i < e.data.table_row; i++) {
						                        editor.insertContent('[table_tr]');
						                        for (j = 0; j < e.data.table_coloumn; j++) {
						                            editor.insertContent('[table_td]content[/table_td]');
						                        }
						                        editor.insertContent('[/table_tr]');
						                    }
					                    editor.insertContent('[/table]');
			                  		}
			                });
			              }
			            }/*finish table*/
      				  ]
      		  }, // end content
		      { // begin box
		      	text: 'Box',
		      	menu: [
		      			{// begin accordion
		      				text:'Accordion',		      				
		      				onclick: function() {
		      					editor.windowManager.open({
		      						title: 'Accordion Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		      						body: [
			      							{
			      								type: 'textbox',
			      								name: 'tabcount',
			      								label: 'How many items ?',
			      								value: '1'
			      							},
			      							{
			      								type: 'label',
			      								name: 'someHelpText',
			      								multiline: true,
							                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
							                    text: "",
							                    onPostRender : function () {
							                    	this.getEl().innerHTML = 
							                    		"Set the items.";
							                    }
			      							},
			      							{
			      								type: 'textbox',
			      								name: 'tabheader',
			      								label: 'Accordion Title',
			      								value: 'Accordion Titile'
			      							},
			      							{
			      								type: 'label',
			      								name: 'someHelpText',
			      								multiline: true,
							                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
							                    text: "",
							                     
			      							},
			      							{
			      								type: 'textbox',
			      								name: 'tabContent',
			      								label: 'Accordion Content',
			      								value: 'Accordion Content'
			      							},
			      							{
			      								type: 'label',
			      								name: 'someHelpText',
			      								multiline: true,
							                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
							                    text: "",
							                     
			      							},
			      							{
												type: 'textbox',
												name: 'elclass',
												label: 'Extra class',
												value: ''
							                },
							                { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
					                        }
		      						],
		      						onsubmit: function( e ) {
	      								editor.insertContent('[df_tabs el_class="'+ e.data.elclass +'" type_tabs="accordion"]');
	      									for (i = 0; i < e.data.tabcount; i++) {
	      										editor.insertContent('[df_tabs_item header="'+ e.data.tabheader +'"]'+e.data.tabContent+'[/df_tabs_item]');
	      									}
	      									editor.insertContent('[/df_tabs]');
		      							}
		      					});
		      				}
		      			}, // end accordion
		      			{ // begin blockquote
		      			  text:'Blockquote',
		      			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Blockquote Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
		                      			{
		                      			  type: 'listbox',
					                      name: 'blockquote_type',
					                      label: 'Blockquote Style',
					                      'values': [
					                      			  { text: 'Type 1', value: '1' },
					                      			  { text: 'Type 2', value: '2' }
					                      		 	]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
		                      			{
		                      			  type: 'textbox',
					                      name: 'border_size',
					                      label: 'Border Size',
					                      value: '4px'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Type 2'";}
				                        },
				                        {
		                      			  type: 'textbox',
					                      name: 'border_color',
					                      label: 'Border Color',
					                      value: '#0F0F0F'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Type 2'";}
				                        },
				                        {
					                      type: 'textbox',
					                      name: 'content',
					                      label: 'Content',
					                      value: 'Hello',
					                      multiline: true,
					                      minWidth: 300,
					                      minHeight: 100
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Write the content.";}
				                        }
		                      		  ],
		                      	onsubmit: function( e ) {
				                    editor.insertContent('[blockquote_sty ver="'+ e.data.blockquote_type +'" border_size="'+e.data.border_size+'" color="'+e.data.border_color+'"]'+e.data.content+'[/blockquote_sty]');
		                  		}
		                    });
			              }
		      			}, // end blockquote
		      			{ // begin Call to action
		      			  text:'Call To Action',
		      			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Call To Action Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
		                      			{
		                      			  type: 'listbox',
		                      			  name: 'cta_style',
		                      			  label: 'CTA Style',
		                      			  'values': [
		                      			  			  {text: 'Normal', value: 'normal'},
		                      			  			  {text: 'Outlined', value: 'outlined'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      
				                        },
				                        {
		                      			  type: 'listbox',
		                      			  name: 'cta_shape',
		                      			  label: 'CTA Shape',
		                      			  'values': [
		                      			  			  {text: 'Square', value: 'square'},
		                      			  			  {text: 'Round', value: 'round'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                    
				                        },
				                        {
					                      type: 'textbox',
										  name: 'cta_bg_color',
										  label: 'CTA Background Color',
										  value: '#FFFFFF'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Normal' style";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'cta_border_color',
										  label: 'CTA Border Color',
										  value: '#EEEEEE'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
				                        {
					                      type: 'textbox',
										  name: 'cta_title_color',
										  label: 'CTA Title Text Color',
										  value: '#0F0F0F'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
				                        {
					                      type: 'textbox',
										  name: 'cta_title_text',
										  label: 'CTA Title Text',
										  value: 'CALL TO ACTION'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      
				                        },
				                        {
					                      type: 'listbox',
					                      name: 'animation_cta',
					                      label: 'CTA Animation',
					                      'values': [
								                      {text: 'No Effect', value: ''},
								                      {text: 'Fade In', value: 'fadeIn'},
								                      {text: 'Fade In Up', value: 'fadeInUp'},
								                      {text: 'Fade In Left', value: 'fadeInLeft'},
								                      {text: 'Fade In Right', value: 'fadeInRight'},
								                      {text: 'Fade In Down', value: 'fadeInDown'}
								                    ]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
		                      			{
		                      			  type: 'listbox',
		                      			  name: 'button_style',
		                      			  label: 'Button Style',
		                      			  'values': [
		                      			  			  {text: 'Flat', value: 'flat'},
		                      			  			  {text: '3D', value: '3d'},
		                      			  			  {text: 'Outline', value: 'outline'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      
				                        },
				                        {
		                      			  type: 'listbox',
		                      			  name: 'button_shape',
		                      			  label: 'Button Shape',
		                      			  'values': [
		                      			  			  {text: 'Square', value: 'square'},
		                      			  			  {text: 'Rounded Rectangled', value: 'rounded'},
		                      			  			  {text: 'Round', value: 'round'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
		                      			{
					                      type: 'textbox',
										  name: 'font_color',
										  label: 'Font Color',
										  value: '#FFFFFF'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      
				                        },
					                    {
					                      type: 'textbox',
										  name: 'button_color',
										  label: 'Button Color',
										  value: '#343435'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Flat' or '3D'.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'border_color',
										  label: 'Border Color',
										  value: '#343435'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                     
				                        },
				                        {
					                      type: 'textbox',
										  name: 'shadow_color',
										  label: 'Shadow Color',
										  value: '#030303'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose '3D'.";}
				                        },
		                      			{
					                      type: 'textbox',
										  name: 'font_color_hover',
										  label: 'Font Color Hover',
										  value: '#FFFFFF'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      
				                        },
					                    {
					                      type: 'textbox',
										  name: 'button_color_hover',
										  label: 'Button Color Hover',
										  value: '#030303'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Flat' or '3D'.";}
				                        },
					                    {
					                      type: 'textbox',
										  name: 'border_color_hover',
										  label: 'Border Color Hover',
										  value: '#030303'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                     
				                        },
					                    {
					                      type: 'textbox',
										  name: 'shadow_color_hover',
										  label: 'Shadow Color Hover',
										  value: '#343435'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose '3D'.";}
				                        },
				                        {
					                      type: 'listbox',
										  name: 'button_size',
										  label: 'Button Size',
										  'values': [
										  			  {text:'Medium', value:'md'},
										  			  {text:'Extra Small', value:'xs'},
										  			  {text:'Small', value:'sm'},
										  			  {text:'Large', value:'lg'}
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                     
				                        },
				                        {
					                      type: 'listbox',
										  name: 'button_position',
										  label: 'Button Position',
										  'values': [
										  			  {text:'Left', value:'position_left'},
										  			  {text:'Center', value:'position_center'},
										  			  {text:'Right', value:'position_right'}
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
				                        {
					                      type: 'textbox',
										  name: 'url_link',
										  label: 'Url Link',
										  value: 'http://'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                    
				                        },
				                        {
					                      type: 'listbox',
										  name: 'target_link',
										  label: 'Target Link',
										  'values': [
										  			  {text:'New Tab', value:'_blank'},
										  			  {text:'Current Tab', value:'_self'}
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Specify where to open the link.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'title_link',
										  label: 'Link\'s tooltip Text',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Write the tooltip text on hover.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'button_text',
										  label: 'Button Text',
										  value: 'BUTTON'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					        
				                        },
				                        {
					                      type: 'textbox',
										  name: 'fa_icon',
										  label: 'Font Awesome Icon',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Check the icon list here <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank' style='font-size:11px;'>Font Awesome</a>, use icon id only. e.g, 'adjust' instead 'fa-adjust'.";}
				                        },
				                        {
					                      type: 'listbox',
										  name: 'icon_size',
										  label: 'Font Awesome Size',
										  'values': [
										  			  {text: '1x', value: '1x'},
										  			  {text: '2x', value: '2x'},
										  			  {text: '3x', value: '3x'},
										  			  {text: '4x', value: '4x'},
										  			  {text: '5x', value: '5x'},
										  			  {text: 'lg', value: 'lg'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_rotate',
										  label: 'Font Awesome Rotate',
										  'values': [
										  			  {text: 'Normal', value: 'normal'},
										  			  {text: 'Rotate 90 Degrees', value: '90'},
										  			  {text: 'Rotate 180 Degrees', value: '180'},
										  			  {text: 'Rotate 270 Degrees', value: '270'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_flip',
										  label: 'Font Awesome Flip',
										  'values': [
										  			  {text: 'None', value: ''},
										  			  {text: 'Horizontal', value: 'horizontal'},
										  			  {text: 'Vertical', value: 'vertical'}
										  			]
					                    },
					                    {
					                      type: 'textbox',
										  name: 'btn_extra_class',
										  label: 'Button Extra Class',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'extra_class',
										  label: 'Extra Class',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        }
		                      		  ],
								onsubmit: function( e ) {
				                    editor.insertContent( '[df_cta_button btn_size="'+e.data.button_size+'" cta_style="'+e.data.cta_style+'" cta_shape="'+e.data.cta_shape+'" bg_color="'+e.data.cta_bg_color+'" border_color="'+e.data.cta_border_color+'" cta_title_color="'+e.data.cta_title_color+'" title="'+e.data.cta_title_text+'" animation="'+e.data.animation_cta+'" el_class="'+e.data.extra_class+'" btn_style="'+e.data.button_style+'" btn_shape="'+e.data.button_shape+'" btn_position="'+e.data.button_position+'" btn_text="'+e.data.button_text+'" font_color="'+e.data.font_color+'" font_color_hover="'+e.data.font_color_hover+'" btn_color="'+e.data.button_color+'" btn_color_hover="'+e.data.button_color_hover+'" btn_border_color="'+e.data.border_color+'" btn_border_color_hover="'+e.data.border_color_hover+'" btn_bottom_color="'+e.data.shadow_color+'" btn_bottom_color_hover="'+e.data.shadow_color_hover+'" url_link="'+e.data.url_link+'" target_link="'+e.data.target_link+'" title_link="'+e.data.title_link+'" type="'+e.data.fa_icon+'" rotate="'+e.data.icon_rotate+'" size="'+e.data.icon_size+'" flip="'+e.data.icon_flip+'" btn_el_class="'+e.data.btn_extra_class+'"]Content[/df_cta_button]');
				                }
		                    });
						  }							      			
		      			}, // end call to action
		      			{ // begin columns
		      			  text:'Columns',
		      			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Columns Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
					                    {
					                      type: 'listbox',
					                      name: 'columnListboxName',
					                      label: 'Add Column',
					                      'values': [
								                      {text: 'Two Column', value: 'two_col'},
								                      {text: 'Three Column', value: 'three_col'},
								                      {text: 'Four Column', value: 'four_col'},
								                      {text: 'Five Column', value: 'five_col'}
								                    ]
					                    } 
					                  ],
				                onsubmit: function( e ) {
				                    if (e.data.columnListboxName == 'two_col') {
					                    editor.insertContent( '[twocol_one] your content [/twocol_one][twocol_one_last] your content [/twocol_one_last]');
				                    } else if (e.data.columnListboxName == 'three_col') {
				                      	editor.insertContent( '[threecol_one] your content [/threecol_one][threecol_one] your content [/threecol_one][threecol_one_last] your content [/threecol_one_last]');
				                    } else if (e.data.columnListboxName == 'four_col') {
				                      	editor.insertContent( '[fourcol_one] your content [/fourcol_one][fourcol_one] your content [/fourcol_one][fourcol_one] your content [/fourcol_one][fourcol_one_last] your content [/fourcol_one_last]');
				                    } else if (e.data.columnListboxName == 'five_col') {
				                      	editor.insertContent( '[fivecol_one] your content [/fivecol_one][fivecol_one] your content [/fivecol_one][fivecol_one] your content [/fivecol_one][fivecol_one] your content [/fivecol_one][fivecol_one_last] your content [/fivecol_one_last]');
				                    }
				                }
		                    });
						  }
		      			}, // end columns
		      			{ // begin modal box
		      			  text:'Modal Box',
		      			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Modal Box Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
		                      			{
		                      			  type:'listbox',
		                      			  name:'modal_on',
		                      			  label:'Modal box trigger setting',
		                      			  'values': [
		                      			  			  {text:'Button', value: 'button'},
		                      			  			  {text:'Text', value: 'text'},
		                      			  			  {text:'Image', value: 'image'},
		                      			  			  {text:'On Load', value: 'onload'},
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "When should the popup be initiated?.";}
				                        },
		                      			{
		                      			  type:'listbox',
		                      			  name:'button_size',
		                      			  label:'Button Size',
		                      			  'values': [
		                      			  			  {text:'Medium', value: 'md'},
		                      			  			  {text:'Block', value: 'block'},
		                      			  			  {text:'Small', value: 'sm'},
		                      			  			  {text:'Large', value: 'lg'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      
				                        },
				                        {
		                      			  type:'textbox',
		                      			  name:'button_bg_color',
		                      			  label:'Button Background Color',
		                      			  value: '#343435'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Button'.";}
				                        },
				                        {
		                      			  type:'textbox',
		                      			  name:'button_txt_color',
		                      			  label:'Button Text Color',
		                      			  value: '#FFFFFF'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Button'.";}
				                        },
				                        {
		                      			  type:'textbox',
		                      			  name:'button_txt',
		                      			  label:'Button Text',
		                      			  value: 'BUTTON'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Button'.";}
				                        },
				                        {
		                      			  type:'textbox',
		                      			  name:'image_url',
		                      			  label:'Image Url',
		                      			  value: ''
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Image'.";}
				                        },
				                        {
		                      			  type:'textbox',
		                      			  name:'txt_color',
		                      			  label:'Text Color',
		                      			  value: ''
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Text'.";}
				                        },
				                        {
		                      			  type:'textbox',
		                      			  name:'txt',
		                      			  label:'Enter Text',
		                      			  value: 'MODAL'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Text'.";}
				                        },
				                        {
		                      			  type:'listbox',
		                      			  name:'modal_on_align',
		                      			  label:'Modal Alignment',
		                      			  'values': [
		                      			  			  {text:'Center', value: 'center'},
		                      			  			  {text:'Left', value: 'left'},
		                      			  			  {text:'Right', value: 'right'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Choose the alignment of your modal button/image/text.";}
				                        },
				                        {
		                      			  type:'textbox',
		                      			  name:'onload_delay',
		                      			  label:'On Load Delay',
		                      			  value: '5'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Time delay before modal popup on page load (in seconds). Active when you choose 'On Load'.";}
				                        },
				                        {
		                      			  type:'listbox',
		                      			  name:'modal_contain',
		                      			  label:'What`s in Modal Popup?',
		                      			  'values': [
		                      			  			  {text:'Miscellaneous Things', value: 'df-html'},
		                      			  			  {text:'Youtube Video', value: 'df-youtube'},
		                      			  			  {text:'Vimeo Video', value: 'df-vimeo'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Choose 'miscellaneous things' if the content is not video.";}
				                        },
		                      			{
		                      			  type:'listbox',
		                      			  name:'modal_size',
		                      			  label:'Modal Size',
		                      			  'values': [
		                      			  			  {text:'Medium', value: 'medium'},
		                      			  			  {text:'Block', value: 'block'},
		                      			  			  {text:'Small', value: 'small'},
		                      			  			  {text:'Container', value: 'container'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "How big the modal box would you like?";}
				                        },
				                        {
		                      			  type:'listbox',
		                      			  name:'modal_style',
		                      			  label:'Modal Animation',
		                      			  'values': [
		                      			  			  {text:'Fade', value: 'overlay-fade'},
		                      			  			  {text:'Slide Up', value: 'overlay-slideup'},
		                      			  			  {text:'Slide Down', value: 'overlay-slidedown'},
		                      			  			  {text:'Slide Right', value: 'overlay-slideright'},
		                      			  			  {text:'Slide Left', value: 'overlay-slideleft'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Choose modal animation.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'content_bg_color',
										  label: 'Content Background Color',
										  value: '#FFFFFF'
					                    },
										{
					                      type: 'textbox',
										  name: 'content_txt_color',
										  label: 'Content Text Color',
										  value: '#0F0F0F'
					                    },
				                        {
					                      type: 'textbox',
										  name: 'header_bg_color',
										  label: 'Header Background Color',
										  value: '#343435'
					                    },
				                        {
					                      type: 'textbox',
										  name: 'header_txt_color',
										  label: 'Header Text Color',
										  value: '#FFFFFF'
					                    },
				                        {
					                      type: 'textbox',
										  name: 'header_txt',
										  label: 'Header Text',
										  value: 'Lorem ipsum dolor si amet.'
					                    },
				                        {
					                      type: 'listbox',
										  name: 'icon_type',
										  label: 'Icon Type',
										  'values': [
										  			  {text: 'No Icon', value: 'none'},
										  			  {text: 'FontAwesome Icon', value: 'fa_icon'},
										  			  {text: 'Image Icon', value: 'image_icon'}
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Choose icon type.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'fa_icon_type',
										  label: 'Font Awesome Icon',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Check the icon list here <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank' style='font-size:11px;'>Font Awesome</a>, use icon id only. e.g, 'adjust' instead 'fa-adjust'.";}
				                        },
				                        {
					                      type: 'listbox',
										  name: 'icon_size',
										  label: 'Font Awesome Size',
										  'values': [
										  			  {text: '1x', value: '1x'},
										  			  {text: '2x', value: '2x'},
										  			  {text: '3x', value: '3x'},
										  			  {text: '4x', value: '4x'},
										  			  {text: '5x', value: '5x'},
										  			  {text: 'lg', value: 'lg'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_rotate',
										  label: 'Font Awesome Rotate',
										  'values': [
										  			  {text: 'Normal', value: 'normal'},
										  			  {text: 'Rotate 90 Degrees', value: '90'},
										  			  {text: 'Rotate 180 Degrees', value: '180'},
										  			  {text: 'Rotate 270 Degrees', value: '270'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_flip',
										  label: 'Font Awesome Flip',
										  'values': [
										  			  {text: 'None', value: ''},
										  			  {text: 'Horizontal', value: 'horizontal'},
										  			  {text: 'Vertical', value: 'vertical'}
										  			]
					                    },
					                    {
					                      type: 'textbox',
										  name: 'icon_image_url',
										  label: 'Icon Image Url',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when choose 'Image Icon'.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'extra_class',
										  label: 'Extra Class',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        }
		                      		  ],
		                      	onsubmit: function( e ) {
		                      		editor.insertContent('[df_modal modal_contain="'+e.data.modal_contain+'" icon_type="'+e.data.icon_type+'" type="'+e.data.fa_icon_type+'" rotate="'+e.data.icon_rotate+'" size="'+e.data.icon_size+'" flip="'+e.data.icon_flip+'" icon_img="'+e.data.icon_image_url+'" modal_on="'+e.data.modal_on+'" btn_size="'+e.data.button_size+'" btn_bg_color="'+e.data.button_bg_color+'" btn_txt_color="'+e.data.button_txt_color+'" btn_text="'+e.data.button_txt+'" btn_img="'+e.data.image_url+'" read_text="'+e.data.txt+'" txt_color="'+e.data.txt_color+'" onload_delay="'+e.data.onload_delay+'" modal_on_align="'+e.data.modal_on_align+'" modal_size="'+e.data.modal_size+'" modal_style="'+e.data.modal_style+'" content_bg_color="'+e.data.content_bg_color+'" content_text_color="'+e.data.content_txt_color+'" header_bg_color="'+e.data.header_bg_color+'" header_text_color="'+e.data.header_txt_color+'" modal_title="'+e.data.header_txt+'" el_class="'+e.data.extra_class+'"]Content[/df_modal]');
		                      	}
		                    });
		                  }
		      			}, // end modal box
		      			{ // begin service
		      			  text:'Service',
		      			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Service Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
		                      			{
					                      type: 'listbox',
					                      name: 'service_layout',
					                      label: 'Icon Location',
					                      'values': [
								                      {text: 'Top center', value: 'top'},
								                      {text: 'Top left', value: 'icon_left'},
								                      {text: 'Left', value: 'left'}
								                    ]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "There are 3 different type layouts.";}
				                        },
				                        {
					                      type: 'listbox',
					                      name: 'icon_type',
					                      label: 'Icon Type',
					                      'values': [
								                      {text: 'FontAwesome Icon', value: 'fa_icon'},
								                      {text: 'Image Icon', value: 'image_icon'}
								                    ]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "There are 2 different type icons.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'fa_icon',
										  label: 'Font Awesome Icon',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Check the icon list here <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank' style='font-size:11px;'>Font Awesome</a>, use icon id only. e.g, 'adjust' instead 'fa-adjust'.";}
				                        },
				                        {
					                      type: 'listbox',
										  name: 'icon_size',
										  label: 'Font Awesome Size',
										  'values': [
										  			  {text: '1x', value: '1x'},
										  			  {text: '2x', value: '2x'},
										  			  {text: '3x', value: '3x'},
										  			  {text: '4x', value: '4x'},
										  			  {text: '5x', value: '5x'},
										  			  {text: 'lg', value: 'lg'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_rotate',
										  label: 'Font Awesome Rotate',
										  'values': [
										  			  {text: 'Normal', value: 'normal'},
										  			  {text: 'Rotate 90 Degrees', value: '90'},
										  			  {text: 'Rotate 180 Degrees', value: '180'},
										  			  {text: 'Rotate 270 Degrees', value: '270'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_flip',
										  label: 'Font Awesome Flip',
										  'values': [
										  			  {text: 'None', value: ''},
										  			  {text: 'Horizontal', value: 'horizontal'},
										  			  {text: 'Vertical', value: 'vertical'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'style_icon',
										  label: 'Style Your Icon',
										  'values': [
										  			  {text: 'Simple', value: 'simple'},
										  			  {text: 'Square', value: 'square'},
										  			  {text: 'Rounded', value: 'rounded'},
										  			  {text: 'Style Your Own Icon', value: 'own'}
										  			]
					                    },
					                    {
	          			  				  type: 'textbox',
	          			  				  name: 'icon_color',
	          			  				  label: 'Icon Color',
	          			  				  value: '#343435'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'icon_bg_color',
	          			  				  label: 'Icon Background Color',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Square', 'Rounded', and 'Style Your Own Icon'.";}
				                        },
					                    {
					                      type: 'listbox',
										  name: 'border_stlye',
										  label: 'Border Style',
										  'values': [
										  			  {text: 'None', value: ''},
										  			  {text: 'Solid', value: 'solid'},
										  			  {text: 'Dashed', value: 'dashed'},
										  			  {text: 'Dotted', value: 'dotted'},
										  			  {text: 'Double', value: 'double'},
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Style Your Own Icon'.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'border_width',
	          			  				  label: 'Border Width',
	          			  				  value: '1'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you enable border style.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'border_radius',
	          			  				  label: 'Border Radius',
	          			  				  value: '50'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you enable border style.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'border_color',
	          			  				  label: 'Border Color',
	          			  				  value: '#0F0F0F'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you enable border style.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'image_url',
	          			  				  label: 'Image Icon',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "add image url. leave blank when you choose fontawesome icon.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'image_width',
	          			  				  label: 'Image Icon Width',
	          			  				  value: '36'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Custom Image width.";}
				                        },
				                        {
					                      type: 'listbox',
					                      name: 'hover_effect',
					                      label: 'Icon Animation on Hover',
					                      'values': [
								                      {text: 'No Effect', value: 'style_1'},
								                      {text: 'Icon Zoom', value: 'style_2'},
								                      {text: 'Icon Bounce Up', value: 'style_3'}
								                    ]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Select the type of effect you want on hover.";}
				                        },
				                        {
					                      type: 'listbox',
					                      name: 'animation_service',
					                      label: 'Service Item Animation',
					                      'values': [
								                      {text: 'No Effect', value: ''},
								                      {text: 'Fade In', value: 'fadeIn'},
								                      {text: 'Fade In Up', value: 'fadeInUp'},
								                      {text: 'Fade In Left', value: 'fadeInLeft'},
								                      {text: 'Fade In Right', value: 'fadeInRight'},
								                      {text: 'Fade In Down', value: 'fadeInDown'}
								                    ]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Choose Load Animation For your Service item.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'url_link',
										  label: 'Url Link',
										  value: 'http://'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Add link to your service item.";}
				                        },
				                        {
					                      type: 'listbox',
										  name: 'target_link',
										  label: 'Target Link',
										  'values': [
										  			  {text:'New Tab', value:'_blank'},
										  			  {text:'Current Tab', value:'_self'}
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Url service target.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'title_link',
										  label: 'Add Service Title',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Url service title.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'title_service',
										  label: 'Title Service',
										  value: 'Title Goes Here'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Service title.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'extra_class',
										  label: 'Extra Class',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        }
		                      		  ],
		                      	onsubmit: function( e ) {
		                      		editor.insertContent('[df_services icon_type="'+e.data.icon_type+'" type="'+e.data.fa_icon+'" size="'+e.data.icon_size+'" rotate="'+e.data.icon_rotate+'" flip="'+e.data.icon_flip+'" img="'+e.data.image_url+'" img_width="'+e.data.image_width+'" icon_color="'+e.data.icon_color+'" icon_style="'+e.data.style_icon+'" icon_bg_color="'+e.data.icon_bg_color+'" border_style="'+e.data.border_stlye+'" border_width="'+e.data.border_width+'" border_radius="'+e.data.border_radius+'" border_color="'+e.data.border_color+'" icon_animation="'+e.data.animation_service+'" hover_effect="'+e.data.hover_effect+'" title="'+e.data.title_service+'" url_link="'+e.data.url_link+'" title_link="'+e.data.title_link+'" target_link="'+e.data.target_link+'" position="'+e.data.service_layout+'" el_class="'+e.data.extra_class+'"]Description Goes Here[/df_services]');
		                      	}
		                    });
		                  }
		      			}, // end service
		      			{// begin tabs
		      				text:'Tabs',		      				
		      				onclick: function() {
		      					editor.windowManager.open({
		      						title: 'Tabs Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		      						body: [
		      							{
		      								type: 'textbox',
		      								name: 'tabcount',
		      								label: 'Number of Tabs',
		      								value: '1'
		      							},
		      							{
		      								type: 'label',
		      								name: 'someHelpText',
		      								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function () {
						                    	this.getEl().innerHTML = 
						                    		"Set the number of tabs to input.";
						                    }
		      							},		      							
		      							{
		      								type: 'listbox',
		      								name: 'tab_align',
		      								label: 'Heading Alignment',
		      								'values': [
			                      			  			  {text: 'Center', value: 'center'},
			                      			  			  {text: 'Left', value: 'left'}
			                      			  		  ]
		      							},
		      							{
		      								type: 'label',
		      								name: 'someHelpText',
		      								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function () {
						                    	this.getEl().innerHTML = 
						                    		"Choose the alignment for tabs heading.";
						                    }
		      							},
		      							{
		      								type: 'textbox',
		      								name: 'tabheader',
		      								label: 'Heading Text',
		      								value: 'Tab '
		      							},
		      							{
		      								type: 'label',
		      								name: 'someHelpText',
		      								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function () {
						                    	this.getEl().innerHTML = 
						                    		"Write heading text.";
						                    }
		      							},
		      							{
						                      type: 'textbox',
											  name: 'elclass',
											  label: 'Extra class',
											  value: ''
						                },
						                { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
					                        }
		      						],
		      						onsubmit: function( e ) {
	      								editor.insertContent('[df_tabs el_class="'+ e.data.elclass +'" heading_align="'+ e.data.tab_align +'" type_tabs="default"]');
	      									for (i = 0; i < e.data.tabcount; i++) {
	      										editor.insertContent('[df_tabs_item header="'+ e.data.tabheader +'"]content[/df_tabs_item]');
	      									}
	      									editor.insertContent('[/df_tabs]');
		      							}
		      					});
		      				}
		      			},// end tabs
		      			{// begin tours
		      				text:'Tours',
		      				onclick: function() {
		      					editor.windowManager.open({
		      						title: 'Tours Shortcode',
		      						style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		      						body: [
		      							{
		      								type: 'textbox',
		      								name: 'toucount',
		      								label: 'Number of tours',
		      								value: '1'
		      							},
		      							{
		      								type: 'label',
		      								name: 'someHelpText',
		      								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function () {
						                    	this.getEl().innerHTML = 
						                    		"Set the number of tours to input.";
						                    }
		      							},
		      							{
		      								type: 'textbox',
		      								name: 'touheader',
		      								label: 'Heading Text',
		      								value: 'Tab '
		      							},
		      							{
		      								type: 'label',
		      								name: 'someHelpText',
		      								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function () {
						                    	this.getEl().innerHTML = 
						                    		"Write heading text.";
						                    }
		      							},
		      							{
						                      type: 'textbox',
											  name: 'elclass',
											  label: 'Extra class',
											  value: ''
						                },
						                { 
						                      type: 'label',
						                      name: 'someHelpText',
						                      multiline: true,
						                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                      text: "",
						                      onPostRender : function() {
						                        this.getEl().innerHTML =
						                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
					                        }		      						
		      						],
		      						onsubmit: function( e ) {
		      							editor.insertContent('[df_tabs el_class="'+ e.data.elclass +'" type_tabs="vertical"]');
		      							for (i = 0; i < e.data.toucount; i++) {
	      									editor.insertContent('[df_tabs_item header="'+ e.data.touheader +'"]content[/df_tabs_item]');
		      							}
	      								editor.insertContent('[/df_tabs]');
		      						}
		      					});
		      				}
		      			},// end tours
		      		  ]
		  	  }, // end box
	          { // begin media
	          	text: 'Media',
	          	menu: [
	          			{ // begin Gmaps
	          			  text: 'Google Maps',
	          			  onclick: function() {
	          			  	editor.windowManager.open({
	          			  		title: 'Gmaps Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
	          			  		body: [
	          			  				{
	          			  				  type: 'listbox',
	          			  				  name: 'fullwidth',
	          			  				  label: 'Enable Full width Map',
	          			  				  'values': [
	          			  				  			  {text: 'Yes', value: 'true'},
	          			  				  			  {text: 'No', value: 'false'}
	          			  				  			]
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
	          			  				{
	          			  				  type: 'listbox',
	          			  				  name: 'custom_color',
	          			  				  label: 'Enable Custom Color',
	          			  				  'values': [
	          			  				  			  {text: 'Yes', value: 'true'},
	          			  				  			  {text: 'No', value: 'no'}
	          			  				  			]
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Enable color customization for google map.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'hue',
	          			  				  label: 'Hue',
	          			  				  value: '#B1A193'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose enable custom color.<br />Sets the hue of the feature to match the hue of the color supplied. Note that the <br />saturation and lightness of the feature is conserved, <br />which means, the feature will not perfectly match the color supplied.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'saturation',
	          			  				  label: 'Saturation',
	          			  				  value: '-50'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose enable custom color.<br />Shifts the saturation of colors by a percentage of the original value if decreasing<br />and a percentage of the remaining value if increasing. Valid values: [-100, 100].";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'lightness',
	          			  				  label: 'Lightness',
	          			  				  value: '10'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose enable custom color.<br />Shifts the saturation of colors by a percentage of the original value if decreasing<br />and a percentage of the remaining value if increasing. Valid values: [-100, 100]";}
				                        },
		      			  				{
	          			  				  type: 'listbox',
	          			  				  name: 'pan_control',
	          			  				  label: 'Enable Control Panel',
	          			  				  'values': [
	          			  				  			  {text: 'Yes', value: 'true'},
	          			  				  			  {text: 'No', value: 'no'}
	          			  				  			]
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
				                        {
	          			  				  type: 'listbox',
	          			  				  name: 'draggable',
	          			  				  label: 'Draggable',
	          			  				  'values': [
	          			  				  			  {text: 'Yes', value: 'true'},
	          			  				  			  {text: 'No', value: 'no'}
	          			  				  			]
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Choose yes to allow your map to be draggable.";}
				                        },
				                        {
	          			  				  type: 'listbox',
	          			  				  name: 'zoom_control',
	          			  				  label: 'Enable Zoom Control',
	          			  				  'values': [
	          			  				  			  {text: 'Yes', value: 'true'},
	          			  				  			  {text: 'No', value: 'no'}
	          			  				  			]
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'zoom_map',
	          			  				  label: 'Map Zoom Level',
	          			  				  value: '14'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Insert zoom level from 1 to 19.";}
				                        },
				                        {
	          			  				  type: 'listbox',
	          			  				  name: 'map_type_control',
	          			  				  label: 'Enable Map Type Picker',
	          			  				  'values': [
	          			  				  			  {text: 'Yes', value: 'true'},
	          			  				  			  {text: 'No', value: 'no'}
	          			  				  			]
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
				                        {
	          			  				  type: 'listbox',
	          			  				  name: 'scale_control',
	          			  				  label: 'Enable Map Scale Control',
	          			  				  'values': [
	          			  				  			  {text: 'Yes', value: 'true'},
	          			  				  			  {text: 'No', value: 'no'}
	          			  				  			]
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
										{
	          			  				  type: 'textbox',
	          			  				  name: 'height_map',
	          			  				  label: 'Map Height',
	          			  				  value: '400'
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Enter map height without px. Example: 200.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'image',
	          			  				  label: 'Custom Marker URL',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Add Image URL For Your Marker.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'latitude1',
	          			  				  label: 'Address 1 : Latitude',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Get your Latitude here <a href='http://itouchmap.com/latlong.html' target='_blank' style='font-size:11px;'>Google Maps</a>.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'longitude1',
	          			  				  label: 'Address 1 : Longitude',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Get Your Longitude here <a href='http://itouchmap.com/latlong.html' target='_blank' style='font-size:11px;'>Google Maps</a>.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'address1',
	          			  				  label: 'Tooltip text for Address 1',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'latitude2',
	          			  				  label: 'Address 2 : Latitude',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Get your Latitude here <a href='http://itouchmap.com/latlong.html' target='_blank' style='font-size:11px;'>Google Maps</a>.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'Address 2 : Longitude',
	          			  				  label: 'Address 2 : Longitude',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Get your Latitude here <a href='http://itouchmap.com/latlong.html' target='_blank' style='font-size:11px;'>Google Maps</a>.";}
				                        },
				                        {
	          			  				  type: 'textbox',
	          			  				  name: 'address2',
	          			  				  label: 'Tooltip text for Address 2',
	          			  				  value: ''
	          			  				},
	          			  				{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Full Address Text (shown in tooltip).";}
				                        },
				                        {
					                      type: 'textbox',
					                      name: 'extra_class',
					                      label: 'Extra Class'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        }
	          			  			  ],
					            onsubmit: function( e ) {
					            	editor.insertContent('[advanced_gmaps fullwidth="'+e.data.fullwidth+'" height="'+e.data.height_map+'" latitude="'+e.data.latitude1+'" longitude="'+e.data.longitude1+'" address="'+e.data.address1+'" latitude_2="'+e.data.latitude2+'" longitude_2="'+e.data.longitude2+'" address_2="'+e.data.address2+'" zoom="'+e.data.zoom_map+'" pan_control="'+e.data.pan_control+'" draggable="'+e.data.draggable+'" zoom_control="'+e.data.zoom_control+'" map_type_control="'+e.data.map_type_control+'" scale_control="'+e.data.scale_control+'" img="'+e.data.image+'" modify_coloring="'+e.data.custom_color+'" hue="'+e.data.hue+'" saturation="'+e.data.saturation+'" lightness="'+e.data.lightness+'" el_class="'+e.data.extra_class+'"]');
					            }
	          			  	});
	          			  }
	          			}, // end Gmaps
	          			{ // begin social icon
	          			  text: 'Social Icon',
	          			  onclick: function() {
	          			  	editor.windowManager.open({
	          			  		title: 'Social Icon Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
	          			  		body: [
	          			  				{
					                      type: 'textbox',
										  name: 'fa_icon',
										  label: 'Social Icon',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Write the icon list, use icon id only. e.g, 'twitter' instead 'fa-twitter'. Check the icon list here <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank' style='font-size:11px;'>Font Awesome</a>";}
				                        },
				                        {
					                      type: 'listbox',
										  name: 'icon_size',
										  label: 'Font Awesome Size',
										  'values': [
										  			  {text: '1x', value: '1x'},
										  			  {text: '2x', value: '2x'},
										  			  {text: '3x', value: '3x'},
										  			  {text: '4x', value: '4x'},
										  			  {text: '5x', value: '5x'},
										  			  {text: 'lg', value: 'lg'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_rotate',
										  label: 'Font Awesome Rotate',
										  'values': [
										  			  {text: 'Normal', value: 'normal'},
										  			  {text: 'Rotate 90 Degrees', value: '90'},
										  			  {text: 'Rotate 180 Degrees', value: '180'},
										  			  {text: 'Rotate 270 Degrees', value: '270'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'icon_flip',
										  label: 'Font Awesome Flip',
										  'values': [
										  			  {text: 'None', value: ''},
										  			  {text: 'Horizontal', value: 'horizontal'},
										  			  {text: 'Vertical', value: 'vertical'}
										  			]
					                    },
					                    {
					                      type: 'listbox',
										  name: 'si_type',
										  label: 'Social Icon Shape',
										  'values': [
										  			  {text:'Normal', value:'normal'},
										  			  {text:'Square', value:'square'},
										  			  {text:'Round', value:'round'},
										  			  {text:'Outline-Square', value:'outline-square'},
										  			  {text:'Outline-Round', value:'outline-round'}
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Choose social icon shape.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'si_color',
										  label: 'Icon Color',
										  value: '#343435'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
				                        {
					                      type: 'textbox',
										  name: 'si_color_hover',
										  label: 'Icon Color Hover',
										  value: '#B1A193'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                       
				                        },
				                        {
					                      type: 'textbox',
										  name: 'si_bg_color',
										  label: 'Icon Background Color',
										  value: '#D5D5D5'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Square' or 'Round'.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'si_bg_color_hover',
										  label: 'Icon Background Color on Hover',
										  value: '#0F0F0F'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Active when you choose 'Square' or 'Round'.";}
				                        },
					                    {
					                      type: 'textbox',
										  name: 'url_link',
										  label: 'Url Link',
										  value: 'http://'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Write Url link.";}
				                        },
				                        {
					                      type: 'listbox',
										  name: 'target_link',
										  label: 'Target Link',
										  'values': [
										  			  {text:'New Tab', value:'_blank'},
										  			  {text:'Current Tab', value:'_self'}
										  			]
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Specify where to open the link.";}
				                        },
				                        {
					                      type: 'textbox',
										  name: 'title_link',
										  label: 'Link\'s tooltip Text',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Write the tooltip text on hover.";}
				                        },
					                    {
					                      type: 'textbox',
										  name: 'extra_class',
										  label: 'Extra Class',
										  value: ''
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        }
	          			  			  ],
      			  			  	onsubmit: function( e ) {
					            	editor.insertContent('[social_icon type="'+e.data.fa_icon+'" size="'+e.data.icon_size+'" rotate="'+e.data.icon_rotate+'" flip="'+e.data.icon_flip+'" url_link="'+e.data.url_link+'" target_link="'+e.data.target_link+'" title_link="'+e.data.title_link+'" si_type="'+e.data.si_type+'" color="'+e.data.si_color+'" color_hover="'+e.data.si_color_hover+'" bg_color="'+e.data.si_bg_color+'" bg_color_hover="'+e.data.si_bg_color_hover+'" el_class="'+e.data.extra_class+'"]');
					            }
	          			  	});
	          			  }
	          			} // end social icon
	          		  ]
	          }, // end media
	          { // begin misc
	          	text: 'Misc',
	          	menu: [
	          			{// begin banner post
	          				text:'Banner Post',
	          				onclick: function() {
	          					editor.windowManager.open({
	          						title: 'Banner Post Shortcode',
	          						style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
	          						body: [
	          							{
	          								type: 'textbox',
	          								name: 'banpost',
	          								label: 'Number of banner post',
	          								value: '' 
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'banorder',
	          								label: 'Order Post',
	          								'values' : [
	          											{text: 'Ascending', value:'ASC'},
	          											{text: 'Descending', value:'DESC'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'banorderby',
	          								label: 'Order By Post',
	          								'values' : [
	          											{text: 'Name', value:'name'},
	          											{text: 'Title', value:'title'},
	          											{text: 'Date', value:'date'},
	          											{text: 'Comment Count', value:'comment_count'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
	          							},	          							
	          							{
	          								type: 'textbox',
	          								name: 'bancat',
	          								label: 'Category',
	          								value: ''
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function() {
						                    	this.getEl().innerHTML = 
					                    		 	"Write category slug, separate with comma (,) for multiple categories.";
						                    }
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'bancolumn',
	          								label: 'Number of Column',
	          								'values' : [
	          											{text: '2', value:'2'},
	          											{text: '3', value:'3'},
	          											{text: '4', value:'4'},
	          											{text: '5', value:'5'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function() {
						                    	this.getEl().innerHTML = 
					                    		 	"Choose number of column.";
						                    }	          								
	          							},
	          							{
	          								type: 'textbox',
	          								name: 'banID',
	          								label: 'Post ID',
	          								value: ''
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function() {
						                    	this.getEl().innerHTML = 
					                    		 	"Write post ID, separate with comma (,) for multiple posts.";
						                    }		          								
	          							},
	          							{
	          								type: 'textbox',
	          								name: 'banheight',
	          								label: 'Banner Height(px)',
	          								value: ''
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function() {
						                    	this.getEl().innerHTML = 
					                    		 	"Set banner post height in px.";
						                    }		          								
	          							},
	          							{
	          								type: 'checkbox',
	          								name: 'readmore',
	          								checked: true,
	          								label: 'Enable Read More',
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    		          								
	          							},
	          							{
	          								type: 'checkbox',
	          								name: 'banslide',
	          								checked: true,
	          								label: 'Enable Slider',
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function() {
						                    	this.getEl().innerHTML = 
					                    		 	"Check to use carousel style.";
						                    }		          								
	          							},
				                        {
					                        type: 'textbox',
										    name: 'banslidenum',
										    label: 'Number Of Post On Slider',
										    value: ''
					                    },
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
						                    style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
						                    text: "",
						                    onPostRender : function() {
						                    	this.getEl().innerHTML = 
					                    		 	"Write the number of post to displayed on the slider.";
						                    }
	          							},
				                        {
					                        type: 'textbox',
										    name: 'elclass',
										    label: 'Extra Class',
										    value: ''
					                    },
					                    { 
					                        type: 'label',
					                        name: 'someHelpText',
					                        multiline: true,
					                        style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                        text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        }	          							
	          						],
		                      	onsubmit: function( e ) {
		                      		editor.insertContent('[banner_post posts="'+e.data.banpost+'" order="'+e.data.banorder+'" orderby="'+e.data.banorderby+'" category="'+e.data.bancat+'" read_more="'+e.data.readmore+'" el_class="'+e.data.elclass+'" grid_col="'+e.data.bancolumn+'" ids="'+e.data.banID+'" height="'+e.data.banheight+'" slider_post="'+e.data.banslide+'" slider_post_number="'+e.data.banslidenum+'"]');
		                      	}	          						
	          					});
	          				}
	          			},// end banner post 
	          			{ // begin contaxt form 7
	          			  text:'Contact Form 7',
	          			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Contact Form 7 Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
		                      			{
		                      			  type: 'textbox',
		                      			  name: 'id',
		                      			  label: 'ID CF7',
		                      			  value: ''
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Enter your contact form 7 id.";}
				                        },
				                        {
		                      			  type: 'listbox',
		                      			  name: 'style',
		                      			  label: 'Contact Form Style',
		                      			  'values': [
		                      			  			  {text:'None', value:''},
		                      			  			  {text:'Transparent', value:'form7_transparent'},
		                      			  			  {text:'Underline', value:'form7_underline'}
		                      			  			]
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Select type of style.";}
				                        },
		                      		  ],
                      		  	onsubmit: function( e ) {
				                    editor.insertContent('[contact-form-7 id="'+e.data.id+'" html_class="'+e.data.style+'"]');
		                  		}
		                    });
		                  }
	          			}, // end contaxt form 7
	          			{ // begin gap
	          			  text:'Gap',
	          			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Gap Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
		                      			{
		                      			  type: 'textbox',
		                      			  name: 'height',
		                      			  label: 'height',
		                      			  value: '20'
		                      			}
		                      		  ],
                      		  	onsubmit: function( e ) {
				                    editor.insertContent('[gap height="'+e.data.height+'"]');
		                  		}
		                    });
		                  }
	          			}, // end gap
	          			{ // begin blog
	          				text:'Blog',
	          				onclick: function() {
	          					editor.windowManager.open({
	          						title: 'Blog Shortcode',
			                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
	          						body: [
	          							{
	          								type: 'textbox',
	          								name: 'blogpost',
	          								label: 'Number of Blog Post',
	          								value: ''
	          							}, 
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'bloglay',
	          								label: 'Grid Layout',
	          								'values' : [
	          												{text:'Fitrows', value:'fitrow'},
	          												{text:'Masonry', value:'masonry'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'blogcol',
	          								label: 'Number of Column',
	          								'values' : [
	          												{text:'2', value:'2'},
	          												{text:'3', value:'3'},
	          												{text:'4', value:'4'},
	          												{text:'5', value:'5'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'blogfilter',
	          								label: 'Enable Isotope Filter',
	          								'values' : [
	          												{text:'True', value:'true'},
	          												{text:'False', value:'false'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
						                    onPostRender : function() {
					                        	this.getEl().innerHTML =
					                            	"Choose true to enable isotope filter.";
					                        }
	          							},
	          							{
	          								type: 'textbox',
	          								name: 'blogcat',
	          								label: 'Category',
	          								value: ''
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
						                    onPostRender : function() {
					                        	this.getEl().innerHTML =
					                            	"Write category slug, separate with comma (,) for multiple categories.";
					                        }
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'blogorder',
	          								label: 'Blog Post Order',
	          								'values' : [
	          											{text:'Ascending', value:'ASC'},
	          											{text:'Descending', value:'DESC'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'blogorderby',
	          								label: 'Blog Post Order By',
	          								'values' : [
	          											{text:'Name', value:'name'},
	          											{text:'Title', value:'title'},
	          											{text:'Date', value:'date'},
	          											{text:'Comment Count', value:'comment_count'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
	          							},
	          							{
	          								type: 'textbox',
	          								name: 'blogID',
	          								label: 'Post ID',
	          								value: ''
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
						                    onPostRender : function() {
					                        	this.getEl().innerHTML =
					                            	"Write post ID, separate with comma (,) for multiple posts.";
					                        }
	          							},
	          							{
	          								type: 'listbox',
	          								name: 'blogslide',
	          								label: 'Enable Carousel',
	          								'values' : [
	          											{text:'True', value:'true'},
	          											{text:'False', value:'false'}
	          										]
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
						                    onPostRender : function() {
					                        	this.getEl().innerHTML =
					                            	"Choose true to enable carousel.";
					                        }
	          							},
	          							{
	          								type: 'textbox',
	          								name: 'blogslidenumb',
	          								label: 'Number of Post in Carousel',
	          								value: ''
	          							},
	          							{
	          								type: 'label',
	          								name: 'someHelpText',
	          								multiline: true,
					                      	style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      	text: "",
						                    onPostRender : function() {
					                        	this.getEl().innerHTML =
					                            	"Write number of post. Active if you choose 'True' in Enable Carousel.";
					                        }
	          							},
				                        {
					                      type: 'textbox',
					                      name: 'elclass',
					                      label: 'Extra Class'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";
					                        }
				                        }
	          						],
                      		  	onsubmit: function( e ) {
				                    editor.insertContent('[blog posts="'+e.data.blogpost+'" grid_layout="'+e.data.bloglay+'" grid_col="'+e.data.blogcol+'" grid_filter="'+e.data.blogfilter+'" category="'+e.data.blogcat+'" order="'+e.data.blogorder+'" orderby="'+e.data.blogorderby+'" ids="'+e.data.blogID+'" slider_post="'+e.data.blogslide+'" slider_post_number="'+e.data.blogslidenumb+'" extra_class="'+e.data.elclass+'"]');
		                  		}
	          					});
	          				}
	          			}, // end blog
	          			{ // begin parallax
	          			  text:'Parallax',
	          			  onclick: function() {
  							editor.windowManager.open({
  								title: 'Parallax Shortcode',
		                      	style: 'overflow-y:auto;overflow-x:hidden;max-height:60%;',
		                      	body: [
		                      			{
		                      			  type: 'textbox',
		                      			  name: 'img_bg',
		                      			  label: 'Parallax Image URL',
		                      			  value: ''
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
				                        {
		                      			  type: 'textbox',
		                      			  name: 'par_width',
		                      			  label: 'Parallax Content Width Area',
		                      			  value: '100%'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
				                        },
				                        {
		                      			  type: 'textbox',
		                      			  name: 'par_height',
		                      			  label: 'Parallax Image Height',
		                      			  value: '480px'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Set parallax height in px.";}
				                        },
				                        {
		                      			  type: 'textbox',
		                      			  name: 'par_padding',
		                      			  label: 'Parallax Padding',
		                      			  value: '20px 0'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "add padding. learn about padding properties <a href='http://www.w3schools.com/cssref/pr_padding.asp' target='_blank'>here</a> ";}
				                        },
				                        {
		                      			  type: 'textbox',
		                      			  name: 'par_class',
		                      			  label: 'Parallax Class',
		                      			  value: 'parout'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Add Parallax Class if you have two or more parallax in a page.";}
				                        },
				                        {
		                      			  type: 'textbox',
		                      			  name: 'par_speed',
		                      			  label: 'Parallax Speed',
		                      			  value: '0.5'
		                      			},
		                      			{ 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "Set parallax speed. Range 0-1";}
				                        },
				                        {
					                      type: 'textbox',
					                      name: 'extra_class',
					                      label: 'Extra Class'
					                    },
					                    { 
					                      type: 'label',
					                      name: 'someHelpText',
					                      multiline: true,
					                      style: 'padding: 5px 0;font-size: 11px;font-style: italic;color: #999;left:auto;text-align:right;',
					                      text: "",
					                      onPostRender : function() {
					                        this.getEl().innerHTML =
					                            "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.";}
				                        }
		                      		  ],
                      		  	onsubmit: function( e ) {
				                    editor.insertContent('[parallax img_bg="'+e.data.img_bg+'" width="'+e.data.par_width+'" height="'+e.data.par_height+'" padding="'+e.data.par_padding+'" class="'+e.data.par_class+'" speed="'+e.data.par_speed+'" el_class="'+e.data.extra_class+'"] your content [/parallax]');
		                  		}
		                    });
		                  }
	          			} // end parallax
	          		  ]
	          } // end misc
	        ]
    }); // editor.addButton
}); // tinymce.PluginManager.add

})(jQuery);