<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * Table
  *
  * Show the Table
  *   
  * @example
  *  
  *  [table][table_tr][table_td]Content 1[/table_td] [table_td]Content 2[/table_td][table_td]Content 3[/table_td][table_td]Content 4[/table_td][/table_tr]
  *  [table_tr][table_td]list[/table_td] [table_td]list[/table_td][table_td]list[/table_td][table_td]list[/table_td][/table_tr]
  *  [table_tr][table_td]list[/table_td] [table_td]list[/table_td][table_td]list[/table_td][table_td]list[/table_td][/table_tr]
  *  [table_tr][table_td]list[/table_td] [table_td]list[/table_td][table_td]list[/table_td][table_td]list[/table_td][/table_tr][/table]
  *
  *  [table ver="2"][table_tr][table_td]Content 1[/table_td] [table_td]Content 2[/table_td][table_td]Content 3[/table_td][table_td]Content 4[/table_td][/table_tr]
  *  [table_tr][table_td]list[/table_td] [table_td]list[/table_td][table_td]list[/table_td][table_td]list[/table_td][/table_tr]
  *  [table_tr][table_td]list[/table_td] [table_td]list[/table_td][table_td]list[/table_td][table_td]list[/table_td][/table_tr]
  *  [table_tr][table_td]list[/table_td] [table_td]list[/table_td][table_td]list[/table_td][table_td]list[/table_td][/table_tr][/table]
  *
  **/

function df_table_sc( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'el_class'  => ''
    ), $atts));

    ob_start();
        
    $out = '<div class="table-responsive '.$el_class.'"><table>'.do_shortcode($content).'</table></div>';
    $out .= ob_get_clean();

    return $out;
}
add_shortcode( 'table', 'df_table_sc' );

/*-----------------------------------------------------------------------------------*/
function df_table_tr_sc( $atts, $content = null ) {
    extract(shortcode_atts(array(     
    ), $atts));

    ob_start();
    $out = '<tr>' . do_shortcode($content) . '</tr>';
    $out .= ob_get_clean();

    return $out;
}
add_shortcode( 'table_tr', 'df_table_tr_sc' );

/*-----------------------------------------------------------------------------------*/
function df_table_td_sc( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));

    ob_start();
    $out = '<td> '. do_shortcode($content) . '</td>';
    $out .= ob_get_clean();

    return $out;
}
add_shortcode( 'table_td', 'df_table_td_sc' );