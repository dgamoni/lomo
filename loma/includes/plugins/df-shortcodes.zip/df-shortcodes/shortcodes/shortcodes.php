<?php
if (!defined('ABSPATH')) die('-1');

/*-----------------------------------------------------------------------------------*/
/* Column 
/*-----------------------------------------------------------------------------------*/
function df_columns_sc( $atts, $content = null, $tag ) {
    extract( shortcode_atts(  array(
        // extra classes
        'class' => ''
    ), $atts ) );
    if ( $class != '' )
        $class = ' ' . $class;
    $last = '';
    // check the shortcode tag to add a "last" class
    if ( strpos( $tag, '_last' ) !== false )
        $tag = str_replace( '_last', ' last', $tag);
    $html = '<div class="' . $tag . $last . $class . '">' . do_shortcode( $content ) . '</div>';
    return apply_filters( 'df_columns_html', $html );
}

$columns = array(
    'twocol_one', // 1/2
    'twocol_one_last', 
    'threecol_one', // 1/3
    'threecol_one_last',
    'fourcol_one', // 1/4
    'fourcol_one_last',
    'threecol_two', // 2/3
    'threecol_two_last',
    'fourcol_three', // 3/4
    'fourcol_three_last',
    'fivecol_one', // 1/5
    'fivecol_one_last'
);
foreach( $columns as $column ) {
    add_shortcode( $column, 'df_columns_sc' );
}

/*-----------------------------------------------------------------------------------*/
/*  Dropcap
/*-----------------------------------------------------------------------------------*/
function df_dropcap_sc ( $atts, $content = null ) {
  $defaults = array(
      'background_color' => '',
      'color' => '',
      'size' => 'normal'
    );

  extract( shortcode_atts( $defaults, $atts ) );
  $html = '';
  if ($background_color != '') {
    $html .= '<span class="dropcap" style="color:'.$color.'; background-color:'.$background_color.'; padding:2px 6px; font-weight:'.$size.' ">' . do_shortcode($content) . '</span><!--/.dropcap-->';

  } elseif ($background_color == '') {
    
    $html .= '<span class="dropcap" style="color:'.$color.'; font-weight:'.$size.'">' . do_shortcode($content) . '</span><!--/.dropcap-->';
  }
  

  return apply_filters( 'df_dropcap_html', $html );
} 

add_shortcode( 'dropcap', 'df_dropcap_sc' );

/*-----------------------------------------------------------------------------------*/
/*  Gap 
/*-----------------------------------------------------------------------------------*/

function df_gap_sc( $atts, $content = null) {

extract( shortcode_atts( array(
      'height'  => '20'
      ), $atts ) );
      
      if($height == '') {
      $return = '';
    }
    else{
      $return = 'style="height: '.$height.'px;"';
    }
      
      $html = '<div class="clear"></div><div class="gap" ' . $return . '></div>';

      return apply_filters( 'df_gap_html', $html );
}

add_shortcode( 'gap', 'df_gap_sc' );

/*-----------------------------------------------------------------------------------*/
/*  Highlight 
/*-----------------------------------------------------------------------------------*/
function df_highlight_sty ( $atts, $content = null ) {
  $defaults = array(
    'background'  => '',
    'color'       => ''
    );

  extract( shortcode_atts( $defaults, $atts ) );

  return '<span class="shortcode-highlight" style="background-color:'.$background.'; color:'.$color.';">' .do_shortcode($content) . '</span>';
} // End df_shortcode_highlight()

add_shortcode( 'highlight_sty', 'df_highlight_sty' );

/*-----------------------------------------------------------------------------------*/
/*  Blockquote 
/*-----------------------------------------------------------------------------------*/
function df_blockquote_sty ( $atts, $content = null ) {
  $defaults = array(
    'border_size' => '4px',
    'color' => '#000',
    'ver' => '1',
    );

  extract( shortcode_atts( $defaults, $atts ) );
  if ($ver == '2') {
    if (is_rtl()) {
      return '<blockquote class="blk2" style="border-right:'.$border_size.' solid '.$color.';">' . do_shortcode($content). '</blockquote> ';
    } else {
      return '<blockquote class="blk2" style="border-left:'.$border_size.' solid '.$color.';">' . do_shortcode($content). '</blockquote> ';
    }
  } else {
    return '<blockquote class="blk">' . do_shortcode($content). '</blockquote> ';
  }
}  

add_shortcode( 'blockquote_sty', 'df_blockquote_sty' );

/*-----------------------------------------------------------------------------------*/
/*  icon list item
/*-----------------------------------------------------------------------------------*/
function df_list_style_sc( $atts, $content = null ) {
    extract(shortcode_atts(array(
      'border_color' => '',
      'border' => '', 
      'border_style' => ''
      ), $atts));
  $out = '<ul class="style-list" style="border:'.$border.';border-style:'.$border_style.';border-color:'.$border_color.'">'. do_shortcode($content) . '<div class="clear"></ul>';
    return $out;
}
add_shortcode( 'list', 'df_list_style_sc' );

function df_item_list_sc( $atts, $content = null ) {
  extract(shortcode_atts(array(
        'icon'      => 'fa-check',
        
    ), $atts));


  $out = '<li><i class="fa '.$icon.'"></i><div class="list_content">'. do_shortcode($content) . '</div></li>';
  
    return $out;
}
add_shortcode( 'list_item', 'df_item_list_sc' );


/*-----------------------------------------------------------------------------------*/
/*  Tool tip
/*-----------------------------------------------------------------------------------*/
function df_tooltip_sc( $atts, $content = null ) {
  extract(shortcode_atts(array(
      'text' => '',
      'link' => '',
      'tooltip' => '',
      'target' => '_self',
      'color' => '',
      'bg_color' => ''
    ), $atts));

wp_enqueue_script('jquery-ui-tooltip');

echo '<style>.ui-tooltip{color: '.$color.';background: '.$bg_color.';}
        .ui-tooltip:before{border-bottom: 5px solid '.$bg_color.';}</style>';

  $out = '<a class="tltp" href="'.$link.'" target="'.$target.'" title="'.$tooltip.'" > '. $text . '</a>';
  
    return $out;
}
add_shortcode( 'tooltip', 'df_tooltip_sc' );

/*-----------------------------------------------------------------------------------*/
/*  Font Awesome                                                                     */
/*-----------------------------------------------------------------------------------*/
function df_fontawesome_sc($atts) {
      extract(shortcode_atts(array(
          'type'  => '',
          'size' => '',
          'rotate' => '',
          'flip' => '',
          'pull' => '',
          'animated' => '',
      ), $atts));
     
    $type = ($type) ? 'fa-'.$type. '' : '';
    $size = ($size) ? 'fa-'.$size. '' : '';
    $rotate = ($rotate) ? 'fa-rotate-'.$rotate. '' : '';
    $flip = ($flip) ? 'fa-flip-'.$flip. '' : '';
    $pull = ($pull) ? 'pull-'.$pull. '' : '';
    $animated = ($animated) ? 'fa-spin' : '';
 
    $html = '<i class="fa '.sanitize_html_class($type).' '.sanitize_html_class($size).' '.sanitize_html_class($rotate).' '.sanitize_html_class($flip).' '.sanitize_html_class($pull).' '.sanitize_html_class($animated).'"></i>';
     
    return apply_filters( 'df_fontawesome_html', $html );
}
 
add_shortcode('icon', 'df_fontawesome_sc');

$shortcodes = array(
      'table.php',
      'advance-gmaps.php',
      'services.php',
      'button.php',
      'cta_button.php',
      'divider.php',
      'banner_post.php',
      'modal.php',
      'tab.php',
      'social.php',
      'parallax.php',
      'blog.php',
      // 'counter.php',
      // 'member.php',
      // 'testimonial.php',
      // 'share.php',
      // 'portfolio.php',
      // 'df-slider.php',
      // 'event-calendar.php'
);

foreach ($shortcodes as $sc ) {
  require_once $sc;
}