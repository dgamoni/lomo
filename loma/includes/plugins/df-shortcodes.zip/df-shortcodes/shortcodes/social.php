<?php
if (!defined('ABSPATH')) die('-1');

/**  
 * Show Social Icon
 * 
 * @example
 *    
 * [social_icon type="" rotate="" size="" flip="" url_link="" target_link="" title_link="" si_type="" color="" color_hover="" bg_color="" bg_color_hover="" icon_size="" el_class=""]
**/
function df_social_icon_sc($atts ) {
    extract(shortcode_atts(array(
      'type'                => '',
      'size'                => '',
      'rotate'              => '',
      'flip'                => '',
      'url_link'            => '',
      'target_link'         => '',
      'title_link'          => '',
      'si_type'             => '',
      'color'               => '',
      'color_hover'         => '',
      'bg_color'            => '',
      'bg_color_hover'      => '',
      'icon_size'           => '',
      'el_class'            => ''
    ), $atts));

    ob_start();

    $logo = do_shortcode('[icon type="'.$type.'" size="'.$size.'" rotate="'.$rotate.'" flip="'.$flip.'"]');

    // class options
    $class = 'social-sc';
    $class .= ( $si_type == 'outline-round' ) ? ' outline-round' : ''; 
    $class .= ( $si_type == 'round' ) ? ' round' : '';

    // attribute options
    $data_attr = '';
    if ( '' != $si_type ) { $data_attr .= ' data-si-class="' . $si_type . '"'; }
    if ( '' != $color ) { $data_attr .= ' data-si-color="' . $color . '"'; }
    if ( '' != $color_hover ) { $data_attr .= ' data-si-color-hover="' . $color_hover . '"'; }
    if ( '' != $bg_color ) { $data_attr .= ' data-si-bg-color="' . $bg_color . '"'; }
    if ( '' != $bg_color_hover ) { $data_attr .= ' data-si-bg-color-hover="' . $bg_color_hover . '"'; }

    // social icon html
    $social_icon = '    
      <a href="'.esc_url($url_link).'" target="'.$target_link.'" title="'.esc_attr( trim($title_link) ).'" class="'.esc_attr( trim($class) ).' '.esc_attr( trim($el_class) ).'" '.$data_attr.'>
      '.$logo.'
      </a>';
    
    $social_icon .= ob_get_clean();

  return $social_icon;
}
add_shortcode('social_icon', 'df_social_icon_sc');