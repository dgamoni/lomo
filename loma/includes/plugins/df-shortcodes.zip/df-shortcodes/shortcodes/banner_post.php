<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * Banner Post
  *   
  * @example
  * [banner_post posts="1,2,3,4,...,n" order="" orderby="" category="" read_more="" el_class="" grid_col="" ids="" height="" slider_post="" slider_post_number=""]
**/

function df_banner($atts){
	extract(shortcode_atts(array(
        'posts'		  => '-1',
        'order'       => 'DESC',
        'orderby'     => 'date',
        'category'    => '',
        'grid_col'    => '',
        'extra_class' => '',
        'ids'         => '',
		'height'      => '500px',
		'read_more'	  => true,


        'slider_post' => false,
        'slider_post_number' => '3',


    ), $atts));
	
	$class_container = '';

    if ($slider_post != 'true' ) {
        $class_container = 'df_grid_fit';
    }  
    
    if ($grid_col > 1) {
        $grid_col = ' grid_'.$grid_col.'_col ';
    } else {
        $grid_col = ' grid_2_col ';
    }

    if ($ids != '') {
        $ids = explode(',', $ids);
    }

    if($category != ''){
        // string to array
        $str = $category;
        $arr = explode(',', $str);
      
        $args['tax_query'][] = array(
          'taxonomy'  => 'category',
          'field'     => 'slug',
          'terms'     => $arr
        );
    }

	ob_start(); ?>
	
		<?php $args = array(
				'post_type'       => 'post',
				'post_status'     => 'publish',
				'ignore_sticky_posts' => 1,
				'posts_per_page'  => $posts,
				'order'           => $order,
				'orderby'         => $orderby,
				'category_name'   => $category,
				'post__in'        => $ids,

			  );
		      query_posts( $args );
		      if( have_posts() ) : 
		      	?>
        			<div class="shorcode-blog-banner <?php echo $class_container; echo $grid_col; echo $extra_class;?>">
				  		<?php
				  			if ($slider_post != "true") {
				  				df_get_blog_post($read_more, $height);
				  			}
				  			else {
				  				df_get_blog_post_slider($slider_post_number, $read_more, $height);

				  			} 
				  		?>
		  			</div><!--end grid layout -->
		  		<?php 
				wp_reset_query();
		      endif; ?>

<?php 
	return ob_get_clean();
}
add_shortcode('banner_post', 'df_banner');
/* ----------------------------------------------------------------------------------- */
/* shortcode banner post                                                        */
/* ----------------------------------------------------------------------------------- */
if(!function_exists('df_get_blog_post')):
	function df_get_blog_post($read_more, $height) {

		while (have_posts()) : the_post(); 
		?>
		<div class="df_banner_post post">
			<div class="featured-image-sc-post" style="<?php df_get_feature_image();?>height:<?php echo $height; ?>">
				<div class="content-sc-post-banner">
					<div>	
						<?php df_category_blog(); ?>
			      		<header class="entry-header-banner-sc">
							<?php the_title( '<h2 ' . dahz_get_attr( 'entry-title' ) . '><a href="' . get_permalink() . '" rel="bookmark" itemprop="url">', '</a></h2>' ); ?>
						</header><!-- .entry-header -->
						<?php if ($read_more != 'false' ) { ?>
							<a href="<?php echo esc_url(get_permalink(get_the_ID())); ?>" class="banner_post button"><?php _e('Read More', 'dahztheme'); ?></a>
						<?php } ?>
					</div><!-- end content-sc-post-banner-->
				</div><!-- end content-sc-post-banner-->
			</div><!-- end featured-image-sc-post-->
		</div><!-- end df_banner_post post-->
		<?php 
		endwhile;
	}
endif;
/* ----------------------------------------------------------------------------------- */
/* shortcode banner post slider                                                        */
/* ----------------------------------------------------------------------------------- */
if(!function_exists('df_get_blog_post_slider')):
	function df_get_blog_post_slider($slider_post_number, $read_more, $height) {
        $class_blog_slider = 'df-blog-slider-'.rand(0,200);

		?>
            <div class="blog-sc-slider">
                <div id="blog-sc-slider" class="<?php echo $class_blog_slider; ?>" data-image-length="<?php echo $slider_post_number; ?>">
                	<?php 		
                		while (have_posts()) : the_post(); 
					?>
						<div class="df_banner_post">
							<div class="featured-image-sc-post" style="<?php df_get_feature_image();?>height:<?php echo $height; ?>">
								<div class="content-sc-post-banner">
									<div>	
										<?php df_category_blog(); ?>
							      		<header class="entry-header">
											<?php the_title( '<h2 ' . dahz_get_attr( 'entry-title' ) . '><a href="' . get_permalink() . '" rel="bookmark" itemprop="url">', '</a></h2>' ); ?>
										</header><!-- .entry-header -->
										<?php if ($read_more != 'false' ) { ?>
											<a href="<?php echo esc_url(get_permalink(get_the_ID())); ?>" class="banner_post button"><?php _e('Read More', 'dahztheme'); ?></a>
										<?php } ?>
									</div><!-- end content-sc-post-banner-->
								</div><!-- end content-sc-post-banner-->
							</div><!-- end featured-image-sc-post-->
						</div><!-- end df_banner_post post-->
					<?php 
					endwhile;
				  	?>
            	</div>  <!-- #blog-sc-slider -->
            </div>  <!-- .blog-sc-slider -->
		 
		<?php 
	}
endif;
/* ----------------------------------------------------------------------------------- */
/* get featured image for blog sc                                                      */
/* ----------------------------------------------------------------------------------- */
if(!function_exists('df_get_feature_image')):
	function df_get_feature_image() {
	    if (has_post_thumbnail()) {
            $image_url = wp_get_attachment_url(get_post_thumbnail_id(), 'full');
            echo 'background-image:url('.$image_url.');';
		} else if (!has_post_thumbnail()){
			$image_nav 	= get_post_format();
	        $url_src 	= get_template_directory_uri() . '/includes/images/post-formats/big/';

	        switch ($image_nav) {
	            case 'audio': $background_image = $url_src . 'audio.jpg'; break;
	            case 'gallery': $background_image = $url_src . 'gallery.jpg'; break;
	            case 'link': $background_image = $url_src . 'link.jpg'; break;
	            case 'image': $background_image = $url_src . 'image.jpg'; break;
	            case 'quote': $background_image = $url_src . 'quote.jpg'; break;
	            case 'video': $background_image = $url_src . 'video.jpg'; break;
	            case 'chat': $background_image = $url_src . 'standard.jpg'; break;
	            case 'status': $background_image = $url_src . 'standard.jpg'; break;
	            case 'aside': $background_image = $url_src . 'standard.jpg'; break;
	            default: $background_image = $url_src . 'standard.jpg'; break;
	        }
            echo 'background-image:url('.$background_image.');';
		}
	}
endif;