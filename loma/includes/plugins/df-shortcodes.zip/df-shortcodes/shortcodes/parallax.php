<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * Parallax
  *
  * Show Parallax
  *   
  * @example
  *    
  *  [parallax img_bg="" width="100%" height="480px" padding="20px 0" class="parout" img_pos="50%" speed="0.5" el_class=""] your content [/parallax]
  *  
**/


function parallax_sc( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'img_bg' 	=> '',
		'width' 	=> '', 
		'height' 	=> '',
		'padding' 	=> '',
		'class' 	=> 'parout', 
		'img_pos' 	=> '50%', 
		'speed' 	=> '',
		'el_class' 	=> ''
    ), $atts));

	ob_start();

    $uniq 		= rand();
    $ex_class	= 'class="'.$el_class.'"';

	$data_attr = '';
	if ( '' != $height ) { $data_attr .= ' data-height="' . $height . '"'; }
	if ( '' != $width ) { $data_attr .= ' data-width="' . $width . '"'; }
	if ( '' != $img_pos ) { $data_attr .= ' data-position="' . $img_pos . '"'; }
	if ( '' != $speed ) { $data_attr .= ' data-speed="' . $speed . '"'; }

	wp_enqueue_script('parallax');

	$out = '<div id="parallax" '.$ex_class.'>
	  			<div class="parallax_out ' . $class . '-' . $uniq . '" style="background: url('.$img_bg.') 50% 0 no-repeat fixed;" '.$data_attr.'> 
					<div class="parallax_content">
						<div class="parallax_in" style="padding:'.$padding.';">
						'. do_shortcode($content) . '
						</div>
					</div>
				</div> 
			</div>';

	$out .= ob_get_clean();

return $out;

}

add_shortcode( 'parallax', 'parallax_sc' );