<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * CTA Button
  *
  * Show the CTA Button
  *   
  * @example
  *  
  *  [df_cta_button cta_style="" cta_shape="" bg_color="" border_color="" cta_title_color="" cta_font_color="" title="" animation="" el_class="" btn_style="" btn_shape="" btn_position="" btn_text="" font_color="" font_color_hover="" btn_color="" btn_color_hover="" btn_border_color="" btn_border_color_hover="" btn_bottom_color="" btn_bottom_color_hover="" url_link="" target_link="" title_link="" icon_type="fa_icon" type="" rotate="" size="" flip="" btn_el_class=""]
  *  	Description Goes Here
  *  [/df_cta_button]
  *
  **/

function df_cta_button_shortcode( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    // button
		'btn_style'					=> '',
		'btn_shape'					=> '',
		'btn_position'				=> '',
		'btn_text' 					=> __( 'Text on the button', "dahztheme" ),
		'font_color'				=> '',
		'font_color_hover'			=> '',
		'btn_color'					=> '',
		'btn_color_hover'			=> '',
		'btn_border_color'			=> '',
		'btn_border_color_hover'	=> '',
		'btn_bottom_color'			=> '',
		'btn_bottom_color_hover'	=> '',
		'btn_size'					=> '',
		'url_link'					=> '',
		'target_link'				=> '',
		'title_link'				=> '',
		'type'						=> '',
		'rotate'					=> '',
		'size'						=> '',
		'flip'						=> '',
		'btn_el_class'				=> '',
	    // cta button
	    'cta_style'     			=> '',
	    'cta_shape'     			=> '',
	    'bg_color'  				=> '',
	    'border_color' 				=> '',
	    'cta_title_color'			=> '',
	    'title'		 				=> '',
	    'animation'	 				=> '',
	    'el_class'      			=> ''
	), $atts));

	ob_start();

	$button = do_shortcode('[df_button btn_size="'.$btn_size.'" btn_style="'.$btn_style.'" btn_shape="'.$btn_shape.'" btn_position="'.$btn_position.'" btn_text="'.$btn_text.'" font_color="'.$font_color.'" font_color_hover="'.$font_color_hover.'" btn_color="'.$btn_color.'" btn_color_hover="'.$btn_color_hover.'" btn_border_color="'.$btn_border_color.'" btn_border_color_hover="'.$btn_border_color_hover.'" btn_bottom_color="'.$btn_bottom_color.'" btn_bottom_color_hover="'.$btn_bottom_color_hover.'" url_link="'.$url_link.'" target_link="'.$target_link.'" title_link="'.$title_link.'" type="'.$type.'" rotate="'.$rotate.'" size="'.$size.'" flip="'.$flip.'" btn_el_class="'.$btn_el_class.'"]');

	// data attribute
	$data_attr = '';
	if ( '' != $cta_style ) { $data_attr .= ' data-cta-class="' . $cta_style . '"'; }
	if ( '' != $bg_color ) { $data_attr .= ' data-cta-bg-color="' . $bg_color . '"'; }
	if ( '' != $border_color ) { $data_attr .= ' data-cta-border-color="' . $border_color . '"'; }
	if ( '' != $animation ) { $data_attr .= ' data-cta-animation="' . $animation . '"'; } 
	// classes
	if ( $cta_shape == 'square' ) {
		$classes = 'cta_square';
	} else if ( $cta_shape == 'round' ) {
		$classes = 'cta_round';
	}
	if ( $animation != '' ) {
		$classes .= ' animated-cta '; 
	}
	$classes .= $el_class;
	// inline css
	if ( '' != $cta_title_color ) { $title_color = ' style="color:' . $cta_title_color . ' !important;"'; } ?>

	<div class="df_call_to_action df_content_element <?php echo $classes; ?>" <?php echo $data_attr; ?>>
	    <div class="cta_wrapper">
	    	<div class="cta_header"><h3<?php echo $title_color; ?>><?php echo esc_attr( trim( $title ) ); ?></h3></div>
		    <div class="cta_content"><?php echo do_shortcode( $content ); ?></div>
	    </div>
	    <?php if ($url_link!='' && $title_link!='' && $target_link!='') { ?> 
	    	<div class="cta_button"><?php echo $button; ?></div>
	    <?php } ?> 
	</div>
<?php
	return ob_get_clean();
}
add_shortcode('df_cta_button', 'df_cta_button_shortcode');