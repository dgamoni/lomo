<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * Google Maps
  *
  * Show the Google Maps
  *   
  * @example
  *  
  *  [advanced_gmaps height="400" latitude="" longitude="" address="" latitude_2="" longitude_2="" address_2="" zoom="14" pan_control="true" draggable="true" zoom_control="true" map_type_control="true" scale_control="true" img="" modify_coloring="false" hue="#ccc" saturation="" lightness="" el_class=""]
  *
  **/

function advance_gmaps( $atts, $content = null) {
	extract( shortcode_atts( array(
		'fullwidth'			=> 'false',
		'height' 			=> '400',
		'latitude' 			=> '',
		'longitude' 		=> '',
		'address' 			=> '',
		'latitude_2' 		=> '',
		'longitude_2' 		=> '',
		'address_2' 		=> '',
		'zoom' 				=> '14',
		'pan_control' 		=> 'true',
		'draggable' 		=> 'true',
		'zoom_control' 		=> 'true',
		'map_type_control' 	=> 'true',
		'scale_control' 	=> 'true',
		'img' 				=> '',
		'modify_coloring' 	=> 'false',
		'hue' 				=> '#ccc',
		'saturation' 		=> '',
		'lightness' 		=> '',
		'el_class' 			=> ''
	), $atts ));

	ob_start();

	$output = $output_img = $data = $class = $class_fullwidth = '';
	$id 	= mt_rand(99,9999);

    $output_img = $img;

	if ( $longitude == '' && $latitude == '') { return null; }
	if ( $zoom < 1 ) { $zoom = 1; }
	if ( $fullwidth == 'true' ) { $class_fullwidth = 'full-width-content df_row-fluid'; }
	if ( $el_class != '' ) { $class .= $el_class;}
 
	$maps  = '';
	$maps .= '<div class="'.$class.'" style="height:'.$height.'px">
				<div class="'.$class_fullwidth.'">
					<div id="google-map-'.$id.'" class="advanced-gmaps" '.$data.' style="height:'.$height.'px;" data-zoom="'.$zoom.'" data-pin-icon="'.$output_img.'" data-latitude="'.$latitude.'" data-longitude="'.$longitude.'" data-address="'.$address.'" data-latitude2="'.$latitude_2.'" data-longitude2="'.$longitude_2.'" data-address2="'.$address_2.'" data-pan-control="'.$pan_control.'" data-zoom-control="'.$zoom_control.'" data-map-type-control="'.$map_type_control.'" data-scale-control="'.$scale_control.'" data-draggable="'.$draggable.'" data-modify-coloring="'.$modify_coloring.'" data-saturation="'.$saturation.'" data-lightness="'.$lightness.'" data-hue="'.$hue.'"></div>
				</div>
			  </div>';

	$maps .= '<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>';
	$maps .= ob_get_clean();

	return $maps;
}
add_shortcode('advanced_gmaps', 'advance_gmaps');