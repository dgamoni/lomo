<?php

/** 
  * Blog
  *   
  * @example
  * [blog posts="" grid_layout="fitrow/masonry" grid_col="2,3,4 and 5" grid_filter="true/false" category="category slug" order="" orderby="" ids="" slider_post="true/false" slider_post_number="" extra_class=""]
**/

function df_blog_latest_sc($atts){
    extract(shortcode_atts(array(
        'posts'       => '-1',
        'grid_layout' => '',
        'grid_col'    => '',
        'grid_filter' => 'false',
        'category'    => '',
        'order'       => 'DESC',
        'orderby'     => 'date',
        'ids' => '',

        'slider_post' => '',
        'slider_post_number' => '',

        'extra_class' => '',

 
    ), $atts));
    if ($slider_post_number == '') {
        $slider_post_number = '3';
    }

    if ($grid_layout == 'fitrow' ) {
        $grid_layout = 'df_grid_fit';
    } elseif ($grid_layout == 'masonry'){
        $grid_layout = 'df_grid_masonry';
    }
    
    if ($grid_col > 1) {
        $grid_col = ' grid_'.$grid_col.'_col ';
    } 

    if ($ids != '') {
        $ids = explode(',', $ids);
    }

    ob_start(); 

    $args = array(
        'post_type'       => 'post',
        'post_status'     => 'publish',
        'ignore_sticky_posts' => 1,
        'category_name'   => $category,
        'posts_per_page'  => $posts,
        'order'           => $order,
        'orderby'         => $orderby,
        'post__in'        => $ids,
    );
  
    if($category != ''){
        // string to array
        $str = $category;
        $arr = explode(',', $str);
      
        $args['tax_query'][] = array(
          'taxonomy'  => 'category',
          'field'     => 'slug',
          'terms'     => $arr
        );
    } 
    query_posts( $args );

    if( have_posts() ) :  
    ?>
    <div class="blog shorcode-blog <?php echo $extra_class; ?>">
        <?php 
            if ($grid_filter == 'true') {
                df_isotope_category_blog_sc($category); 
            }
        ?>
        <?php if ($slider_post == 'true'){  
            df_slider_blog_sc($slider_post_number);
          }/*end if slider == true*/ else { ?>
        <div class="<?php echo $grid_layout; echo $grid_col;?>">
            <?php 
                    df_blog_sc($grid_layout);   
            ?>
        </div>
        <?php } /*end if slider == false*/ ?>
    </div>
    <?php 
      wp_reset_query();
  
    endif; ?>

 
<?php 

    return ob_get_clean();
}
add_shortcode('blog', 'df_blog_latest_sc');
/* ----------------------------------------------------------------------------------- */
/* If post slider                                                               */
/* ----------------------------------------------------------------------------------- */
if (!function_exists('df_slider_blog_sc')) :
    function df_slider_blog_sc($slider_post_number) {
        
        $class_blog_slider = 'df-blog-slider-'.rand(0,200);
        ?>
            <div class="blog-sc-slider">  
                    <div id="blog-sc-slider" class="<?php echo $class_blog_slider; ?>" data-image-length="<?php echo $slider_post_number; ?>">
                    <?php   while ( have_posts() ) : the_post();
                            $image_before   = '<div class="df-port-image"><div class="view third-effect">';
                            $image_after    = '<div class="mask"><div class="mask-table"><div class="mask-table-cell">';
                            $image_closing  ='</div></div></div></div></div>'; ?>  
                            <div class="blog-sc-content">
                            <?php $image_pf = get_post_format();
                                if (has_post_thumbnail()) {
                                    echo $image_before;
                                    the_post_thumbnail('thumbnail-single-related');
                                    echo $image_after;
                                    switch ($image_pf) {
                                        case 'audio':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'gallery':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'image':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'video':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'quote':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'link':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'aside':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'status':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        case 'chat':
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            break;
                                        default:
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                    }
                                    echo $image_closing;
                                } else {
                                    $url_src = get_template_directory_uri() . '/includes/images/post-formats/big/';
                                    switch ($image_pf) {
                                        case 'audio':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'audio.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'gallery':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'gallery.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'image':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'image.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'video':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'video.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'quote':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'quote.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'link':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'link.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'aside':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'aside.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'status':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'status.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        case 'chat':
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'chat.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                            break;
                                        default:
                                            echo $image_before;
                                            echo '<img src="' . esc_url($url_src) . 'standard.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                                            echo $image_after;
                                            echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                                            echo $image_closing;
                                    }
                                }
                                ?>
                                <p><?php df_category_blog(); ?></p>
                                <h4 class="related-title"><a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a></h4>
                                <p><?php df_post_meta(); ?></p>
                            </div>  
                            <?php
                       endwhile;
                        echo "</div></div><div class='clear'></div>";

        
    }
endif;

/* ----------------------------------------------------------------------------------- */
/* If post                                                               */
/* ----------------------------------------------------------------------------------- */
if (!function_exists('df_blog_sc')) :
    function df_blog_sc($grid_layout) {
       while ( have_posts() ) : the_post();

        $terms = get_the_terms(get_the_id(), 'category');
        if ($terms && !is_wp_error($terms)) :
            $category_links = array();
            foreach ($terms as $term) {
                $category_links[] = $term->slug;
            }
            $category_link = join(" ", $category_links);
        endif;
         

        $image_before   = '<div class="df-port-image"><div class="view third-effect">';
        $image_after    = '<div class="mask"><div class="mask-table"><div class="mask-table-cell">';
        $image_closing  ='</div></div></div></div></div>'; ?>  
        <div class="blog-sc-content post <?php echo $category_link; ?>">
        <?php $image_pf = get_post_format();
            if (has_post_thumbnail()) {
                echo $image_before;
                if ($grid_layout == 'df_grid_masonry') {
                    the_post_thumbnail('full');
                } else {
                    the_post_thumbnail('thumbnail-single-related');
                }
                echo $image_after;
                switch ($image_pf) {
                    case 'audio':
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        break;
                    case 'gallery':
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        break;
                    case 'image':
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        break;
                    case 'video':
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        break;
                    case 'quote':
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        break;
                    case 'link':
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        break;
                    default:
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                }
                echo $image_closing;
            } else {
                $url_src = get_template_directory_uri() . '/includes/images/post-formats/big/';
                switch ($image_pf) {
                    case 'audio':
                        echo $image_before;
                        echo '<img src="' . esc_url($url_src) . 'audio.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                        echo $image_after;
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        echo $image_closing;
                        break;
                    case 'gallery':
                        echo $image_before;
                        echo '<img src="' . esc_url($url_src) . 'gallery.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                        echo $image_after;
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        echo $image_closing;
                        break;
                    case 'image':
                        echo $image_before;
                        echo '<img src="' . esc_url($url_src) . 'image.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                        echo $image_after;
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        echo $image_closing;
                        break;
                    case 'video':
                        echo $image_before;
                        echo '<img src="' . esc_url($url_src) . 'video.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                        echo $image_after;
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        echo $image_closing;
                        break;
                    case 'quote':
                        echo $image_before;
                        echo '<img src="' . esc_url($url_src) . 'quote.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                        echo $image_after;
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        echo $image_closing;
                        break;
                    case 'link':
                        echo $image_before;
                        echo '<img src="' . esc_url($url_src) . 'link.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                        echo $image_after;
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        echo $image_closing;
                        break;
                    default:
                        echo $image_before;
                        echo '<img src="' . esc_url($url_src) . 'standard.jpg" class="attachment-thumbnail-single-related wp-post-image" alt="">';
                        echo $image_after;
                        echo '<a href="' . esc_url(get_the_permalink()) . '" class="info"  rel=""></a>';
                        echo $image_closing;
                }
            }
            ?>
            <div class="df-post-content">
                <header class="entry-header">
                    <?php df_category_blog(); ?>
                    <h2 class="df-post-title"><a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a></h2>
                     <?php df_post_meta(); ?> 
                </header>
                <div class="entry-summary">
                     <?php the_excerpt(); ?>
                </div>
                <?php df_extra_button_post(); ?>
            </div>  

        </div>  
        <?php
       endwhile;
        echo "<div class='clear'></div>";

        
    }
endif;

/* ----------------------------------------------------------------------------------- */
/* Isotope Category Grid                                                               */
/* ----------------------------------------------------------------------------------- */
if (!function_exists('df_isotope_category_blog_sc')) :

    function df_isotope_category_blog_sc($category) {
            if ($category != '') {
                $arr_category = (explode(",",$category));
                
                // category inculde blog
                $cat_count_inc = count($arr_category);
                if ($cat_count_inc > 0) {
                    foreach ($arr_category as $catinc) {
                        $term = get_term_by('slug', $catinc , 'category'); 
                        $category_inc[] = $term->term_id;

                    }
                }
            } else {
                $category_inc = '';
            }

            $terms = get_terms( 'category', array(
                'include' => $category_inc,

             ) );

            $html = '<ul id="options-blog-sort">';
            $html .= '<li><a href="#" data-option-value="*" data-filter="*" class="selected">' . __('View All', 'dahztheme') . '</a></li>';

            foreach ($terms as $term) {
                $html .= "<li><a href='#' data-filter='.{$term->slug}'>{$term->name}</a></li>";
            }

            $html .= '</ul><div class="clear"></div>';

            echo $html;

    }

endif;
 