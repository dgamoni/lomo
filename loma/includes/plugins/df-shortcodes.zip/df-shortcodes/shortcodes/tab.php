<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * TABS
  *   
  * @example  [df_tabs el_class="tabs-1" heading_align="center/left" type_tabs="default/vertical"][df_tabs_item header="tabs 1"]your content.[/df_tabs_item][df_tabs_item header="tabs 2"]your content.[/df_tabs_item][df_tabs_item header="tabs 3"]your content.[/df_tabs_item][df_tabs_item header="tabs 4"]your content.[/df_tabs_item][/df_tabs]
**/

function df_shortcode_tabs( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'el_class'  => '',
        'heading_align' => '',
        'type_tabs' => 'default',
    ), $atts));

    ob_start();

    if ($type_tabs == 'default') {
        $class = 'df_tabs';
    } else if ($type_tabs == 'vertical') {
        $class = 'df_tours';
    } else if ($type_tabs == 'accordion') {
        $class = 'df_accordion';
    }

    $out = '';
    $out .= '<div class="tabs-shortcode '.$class.' '.$heading_align.' '.$el_class.'" data-type-tabs="'.$type_tabs.'"><ul class="resp-tabs-list"></ul><div class="resp-tabs-container"> '.do_shortcode($content).'</div><div class="clear"></div></div>';
    $out .= ob_get_clean();
     
    return $out;
}
 
function df_shortcode_tabs_item( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'header'  => ''

    ), $atts));

    ob_start();
	$out = '';
    $out .= '<div class="tabs-sc-content" data-header="'.$header.'">'. do_shortcode($content) . '</div>';
    $out .= ob_get_clean();
    return $out;
}
add_shortcode( 'df_tabs', 'df_shortcode_tabs' );
add_shortcode( 'df_tabs_item', 'df_shortcode_tabs_item' );