<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * Divider with text
  *   
  * @example [df_divider_text title="" title_align="" el_width="" style="" height="" accent_color="" border_size="" padding="" position="" el_class=""]
**/
function df_divider_text( $atts) {
	extract(shortcode_atts(array(
	    'title'         => '',
	    'title_align'   => '',
	    'el_width'      => '',
	    'style'         => '',
	    'height'        => '',
	    'accent_color'  => '',
	    'border_size'   => '',
	    'padding'       => '',
	    'position'      => '',
	    'el_class'      => ''
	), $atts));

	ob_start();

	$class = "df_separator df_content_element";

	$class .= ($title_align!='') ? ' df_'.$title_align : '';
	$class .= ($el_width!='') ? ' df_el_width_'.$el_width : ' df_el_width_100';
	$class .= ($style!='') ? ' df_sep_'.$style : '';
	$class .= ($position!='') ? ' df_sep_position_'.$position : '';

	$inline_css = ( $accent_color!='') ? 'style="border-color: '.$accent_color.';border-width:'.$border_size.';height: '.$height.';"' : 
	                'style="border-width:'.$border_size.'; height: '.$height.';"'; ?>

	<div class="<?php echo esc_attr(trim($class)); ?> <?php echo esc_attr(trim($el_class)); ?>" style="padding: <?php echo $padding ?>;">
	    <span class="df_sep_holder df_sep_holder_l"><span <?php echo $inline_css; ?> class="df_sep_line"></span></span>
	    <?php if($title!=''): ?><h4><?php echo $title; ?></h4><?php endif; ?>
	    <span class="df_sep_holder df_sep_holder_r"><span <?php echo $inline_css; ?> class="df_sep_line"></span></span>
	</div>
<?php
	return ob_get_clean();
}
add_shortcode('df_divider_text', 'df_divider_text');

/** 
  * Divider
  *   
  * @example [df_divider el_width="" style="" height="" accent_color="" border_size="" padding="" position="" el_class=""]
**/
function df_divider( $atts ) {
	extract( shortcode_atts( array(
		'el_width' 		=> '',
		'style' 		=> '',
		'height'		=> '',
		'accent_color' 	=> '',
		'border_size'	=> '',
		'padding'		=> '',
		'position'		=> '',
		'el_class' 		=> ''
	), $atts ) );

	ob_start();

	echo do_shortcode( '[df_divider_text style="' . $style . '" height="' . $height . '" accent_color="' . $accent_color . '" el_width="' . $el_width . '" el_class="' . $el_class . '" border_size="'.$border_size.'" padding="'.$padding.'" position="'.$position.'"]' );

	return ob_get_clean();
}
add_shortcode('df_divider', 'df_divider');