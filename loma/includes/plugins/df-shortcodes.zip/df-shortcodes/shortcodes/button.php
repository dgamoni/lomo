<?php
if (!defined('ABSPATH')) die('-1');

/** 
  * Button
  *
  * Show the Button
  *   
  * @example
  *  
  *  [df_button btn_style="" btn_shape="" btn_position="" btn_text="" font_color="" font_color_hover="" btn_color="" btn_color_hover="" btn_border_color="" btn_border_color_hover="" btn_bottom_color="" btn_bottom_color_hover="" url_link="" target_link="" title_link="" icon_type="fa_icon" type="" rotate="" size="" flip="" btn_el_class=""]
  *
  **/

function df_button( $atts ) {
	extract( shortcode_atts( array(
		'btn_style'					=> '',
		'btn_shape'					=> '',
		'btn_position'				=> '',
		'btn_text' 					=> __( 'Text on the button', "dahztheme" ),
		'font_color'				=> '',
		'font_color_hover'			=> '',
		'btn_color'					=> '',
		'btn_color_hover'			=> '',
		'btn_border_color'			=> '',
		'btn_border_color_hover'	=> '',
		'btn_bottom_color'			=> '',
		'btn_bottom_color_hover'	=> '',
		'btn_size'					=> '',
		'url_link'					=> '',
		'target_link'				=> '',
		'title_link'				=> '',
		'type'						=> '',
		'rotate'					=> '',
		'size'						=> '',
		'flip'						=> '',
		'btn_el_class'				=> ''
	), $atts ) );

	ob_start();

	$logo = do_shortcode('[icon type="'.$type.'" size="'.$size.'" rotate="'.$rotate.'" flip="'.$flip.'"]');

	$class = 'btn';
	$class .= ( $btn_size != '' ) ? ' btn_' . $btn_size : '';
	$class .= ( $btn_shape != '' ) ? ' btn_' . $btn_shape : '';
	
	$data_attr = '';
	if ( '' != $btn_style ) { $data_attr .= ' data-button-class="' . $btn_style . '"'; }
	if ( '' != $btn_color ) { $data_attr .= ' data-button-color="' . $btn_color . '"'; }
	if ( '' != $btn_color_hover ) { $data_attr .= ' data-button-color-hover="' . $btn_color_hover . '"'; }
	if ( '' != $btn_border_color ) { $data_attr .= ' data-button-border-color="' . $btn_border_color . '"'; }
	if ( '' != $btn_border_color_hover ) { $data_attr .= ' data-button-border-color-hover="' . $btn_border_color_hover . '"'; }
	if ( '' != $btn_bottom_color ) { $data_attr .= ' data-button-bottom-color="' . $btn_bottom_color . '"'; }
	if ( '' != $btn_bottom_color_hover ) { $data_attr .= ' data-button-bottom-color-hover="' . $btn_bottom_color_hover . '"'; }
	if ( '' != $font_color ) { $data_attr .= ' data-font-color="' . $font_color . '"'; }
	if ( '' != $font_color_hover ) { $data_attr .= ' data-font-color-hover="' . $font_color_hover . '"'; } ?>

	<div class="btn_warpper <?php echo $btn_position; ?>">
		<a class="<?php echo esc_attr( trim( $btn_el_class ) ); ?> <?php echo esc_attr( trim( $class ) ); ?>" href="<?php echo esc_url($url_link); ?>" title="<?php echo esc_attr( $title_link ); ?>" target="<?php echo $target_link; ?>" <?php echo $data_attr; ?>>
			<?php if ( $type != '' ) { ?>
				<span><?php echo $btn_text; ?> <?php echo $logo; ?></span>
			<?php } else { ?>			
				<span><?php echo $btn_text; ?></span>
			<?php } ?>			
		</a>
	</div>
<?php
	return ob_get_clean();
}
add_shortcode('df_button', 'df_button');